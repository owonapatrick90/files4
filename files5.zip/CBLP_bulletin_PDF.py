"""
COLLEGE BILINGUE LA PENSEE
Module: Génération PDF des bulletins de notes — Norme APC MINESEC Cameroun
Auteur: OWONA MBARGA MATHIEU PATRICK — Ingénieur Informatique
Tel: +237 691 105 604 / 671 659 226
"""

import os, io, sqlite3, hashlib, qrcode
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm, mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, PageBreak, KeepTogether
)
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ── COULEURS OFFICIELLES CBLP ──────────────────────────────────────────────────
BLEU_FONCE  = colors.HexColor('#0D47A1')
BLEU        = colors.HexColor('#1565C0')
BLEU_CLAIR  = colors.HexColor('#E3F2FD')
BLEU_MED    = colors.HexColor('#BBDEFB')
OR          = colors.HexColor('#F9A825')
OR_FONCE    = colors.HexColor('#F57F17')
VERT        = colors.HexColor('#2E7D32')
VERT_CLAIR  = colors.HexColor('#E8F5E9')
ROUGE       = colors.HexColor('#C62828')
ROUGE_CLAIR = colors.HexColor('#FFEBEE')
ORANGE      = colors.HexColor('#E65100')
ORANGE_CL   = colors.HexColor('#FFF3E0')
GRIS_F      = colors.HexColor('#424242')
GRIS        = colors.HexColor('#757575')
GRIS_CL     = colors.HexColor('#F5F5F5')
BLANC       = colors.white

W, H = A4  # 595.28 x 841.89 points

# ── MATIÈRES COLLÈGE (APC) ────────────────────────────────────────────────────
MATIERES_COLLEGE = [
    {'dom': 'Langages & Communication',  'mat': 'Langue Française',                'c': 4},
    {'dom': 'Langages & Communication',  'mat': 'Langue Anglaise',                 'c': 3},
    {'dom': 'Mathématiques',             'mat': 'Mathématiques',                   'c': 5},
    {'dom': 'Sciences de la Nature',     'mat': 'Sciences de la Vie et de la Terre','c': 3},
    {'dom': 'Sciences de la Nature',     'mat': 'Physique-Chimie',                 'c': 3},
    {'dom': 'Sciences Humaines',         'mat': 'Histoire-Géographie',             'c': 2},
    {'dom': 'Sciences Humaines',         'mat': 'Éduc. Citoyenneté & Morale',      'c': 2},
    {'dom': 'Sciences Humaines',         'mat': 'Études Religieuses',              'c': 2},
    {'dom': 'Technologie & Numérique',   'mat': 'Informatique & TIC',              'c': 2},
    {'dom': 'Arts, Culture & Créativité','mat': 'Éduc. Artistique & Musicale',     'c': 1},
    {'dom': 'Santé & Bien-être',         'mat': 'Éduc. Physique & Sportive',       'c': 1},
]

MATIERES_LYCEE = [
    {'dom': 'Langages & Communication',  'mat': 'Langue Française',                'c': 4},
    {'dom': 'Langages & Communication',  'mat': 'Langue Anglaise',                 'c': 3},
    {'dom': 'Mathématiques',             'mat': 'Mathématiques',                   'c': 5},
    {'dom': 'Sciences de la Nature',     'mat': 'Sciences de la Vie et de la Terre','c': 3},
    {'dom': 'Sciences de la Nature',     'mat': 'Physique-Chimie',                 'c': 4},
    {'dom': 'Sciences Humaines',         'mat': 'Histoire-Géographie',             'c': 2},
    {'dom': 'Sciences Humaines',         'mat': 'Philosophie',                     'c': 3},
    {'dom': 'Sciences Humaines',         'mat': 'Économie Générale',               'c': 2},
    {'dom': 'Sciences Humaines',         'mat': 'Études Religieuses',              'c': 2},
    {'dom': 'Technologie & Numérique',   'mat': 'Informatique',                    'c': 2},
    {'dom': 'Santé & Bien-être',         'mat': 'Éduc. Physique & Sportive',       'c': 1},
]

# ── UTILITAIRES ───────────────────────────────────────────────────────────────

def _appreciation(note):
    if note is None: return '—'
    if note >= 18: return 'Excellent'
    if note >= 15: return 'Très bien'
    if note >= 13: return 'Bien'
    if note >= 10: return 'Assez bien'
    if note >=  8: return 'Insuffisant'
    return 'Très insuff.'

def _couleur_note(note):
    if note is None: return GRIS
    if note >= 13: return VERT
    if note >= 10: return BLEU_FONCE
    if note >=  8: return ORANGE
    return ROUGE

def _decision(moy):
    if moy >= 10: return ('ADMIS(E)', VERT)
    if moy >=  8: return ('RACHAT',   ORANGE)
    return ('ÉCHEC', ROUGE)

def _mention(moy):
    if moy >= 18: return 'Excellent'
    if moy >= 16: return 'Très bien'
    if moy >= 14: return 'Bien'
    if moy >= 12: return 'Assez bien'
    if moy >= 10: return 'Passable'
    return '—'

def _fmt_date(s):
    if not s: return '—'
    try:
        d = datetime.strptime(s[:10], '%Y-%m-%d')
        mois = ['Janvier','Février','Mars','Avril','Mai','Juin',
                'Juillet','Août','Septembre','Octobre','Novembre','Décembre']
        return f"{d.day} {mois[d.month-1]} {d.year}"
    except: return s

def _gen_qr(data, size=60):
    """Génère un QR code en bytes PNG."""
    qr = qrcode.QRCode(version=2, error_correction=qrcode.constants.ERROR_CORRECT_M,
                       box_size=3, border=1)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color='#0D47A1', back_color='white')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf

def _style(name, **kwargs):
    """Crée un style paragraphe rapide."""
    base = ParagraphStyle(name)
    base.fontName = 'Helvetica'
    base.fontSize = 8
    base.leading = 10
    for k, v in kwargs.items():
        setattr(base, k, v)
    return base

# ── CLASSE PRINCIPALE ─────────────────────────────────────────────────────────

class BulletinPDF:
    """
    Génère le bulletin APC officiel du COLLEGE BILINGUE LA PENSEE.
    Conforme à la norme MINESEC Cameroun.
    """

    def __init__(self, output_dir='static/bulletins'):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generer_bulletin(self, data: dict) -> str:
        """
        Génère le bulletin PDF pour un élève donné.
        data = {
            'eleve': {...}, 'classe': {...}, 'sequence': 1,
            'notes': [{'mat':..,'note':..,'c':..,'prof':..},...],
            'bulletin': {'moyenne':..,'rang':..,'total':..,'decision':..,...},
            'annee': '2024-2025', 'section': 'fr'
        }
        Retourne le chemin du fichier PDF généré.
        """
        el    = data['eleve']
        cls   = data['classe']
        seq   = data.get('sequence', 1)
        bul   = data.get('bulletin', {})
        annee = data.get('annee', '2024-2025')
        notes = data.get('notes', [])

        # Nom de fichier unique
        fname = f"bulletin_{el['matricule']}_S{seq}_{annee.replace('-','')}.pdf"
        fpath = os.path.join(self.output_dir, fname)

        # URL QR code (bulletin numérique en ligne)
        qr_url = f"https://cblp.cm/bulletins/{el['matricule']}/S{seq}/{annee}"

        doc = SimpleDocTemplate(
            fpath,
            pagesize=A4,
            rightMargin=1.2*cm, leftMargin=1.2*cm,
            topMargin=0.8*cm, bottomMargin=0.8*cm,
            title=f"Bulletin — {el['nom']} {el['prenom']} — Séquence {seq}",
            author="COLLEGE BILINGUE LA PENSEE",
        )

        story = []

        # ── 1. EN-TÊTE ────────────────────────────────────────────────────────
        story.append(self._entete(el, cls, seq, annee, qr_url))
        story.append(Spacer(1, 3*mm))

        # ── 2. BANDEAU INFOS ÉLÈVE ────────────────────────────────────────────
        story.append(self._infos_eleve(el, cls, bul))
        story.append(Spacer(1, 2*mm))

        # ── 3. TABLEAU DES NOTES APC ──────────────────────────────────────────
        story.append(self._tableau_notes(notes, data.get('section','fr')))
        story.append(Spacer(1, 2*mm))

        # ── 4. SYNTHÈSE (MOYENNE / RANG / DÉCISION) ───────────────────────────
        story.append(self._synthese(bul, notes))
        story.append(Spacer(1, 2*mm))

        # ── 5. APPRÉCIATIONS & DISCIPLINE ────────────────────────────────────
        story.append(self._appreciations(bul))
        story.append(Spacer(1, 2*mm))

        # ── 6. SIGNATURES ─────────────────────────────────────────────────────
        story.append(self._signatures(cls, annee))
        story.append(Spacer(1, 2*mm))

        # ── 7. PIED DE PAGE ───────────────────────────────────────────────────
        story.append(self._pied_de_page(el, seq, annee))

        doc.build(story)
        print(f"[CBLP] Bulletin généré : {fpath}")
        return fpath

    # ── BLOC 1 — EN-TÊTE ──────────────────────────────────────────────────────
    def _entete(self, el, cls, seq, annee, qr_url):
        seq_label = f"Séquence {seq}" if isinstance(seq, int) and seq <= 6 else \
                    f"Trimestre {seq[1]}" if str(seq).startswith('T') else "Annuel"

        # QR code
        try:
            qr_buf = _gen_qr(qr_url, 60)
            qr_img = Image(qr_buf, width=1.8*cm, height=1.8*cm)
        except Exception:
            qr_img = Paragraph('<b>QR</b>', _style('qr', fontSize=8, alignment=TA_CENTER))

        # Logo (emoji remplacé par cercle coloré)
        logo_cell = Table([['']], colWidths=[1.8*cm], rowHeights=[1.8*cm])
        logo_cell.setStyle(TableStyle([
            ('BACKGROUND',  (0,0),(0,0), BLEU),
            ('ROUNDEDCORNERS', [50]),
            ('ALIGN',       (0,0),(0,0), 'CENTER'),
            ('VALIGN',      (0,0),(0,0), 'MIDDLE'),
        ]))

        # Centre
        centre_data = [
            [Paragraph('REPUBLIQUE DU CAMEROUN — PAIX · TRAVAIL · PATRIE',
                _style('rep', fontSize=7, alignment=TA_CENTER, textColor=GRIS))],
            [Paragraph('MINESEC — Enseignement Secondaire Général',
                _style('min', fontSize=6.5, alignment=TA_CENTER, textColor=GRIS))],
            [Spacer(1, 1*mm)],
            [Paragraph('COLLÈGE BILINGUE LA PENSÉE',
                _style('school', fontSize=15, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, textColor=BLEU_FONCE))],
            [Paragraph('B.P. 001 Yaoundé · Tél: +237 699 000 000 · contact@cblp.cm',
                _style('addr', fontSize=7, alignment=TA_CENTER, textColor=GRIS))],
            [Spacer(1, 1.5*mm)],
            [Paragraph(f'BULLETIN DE NOTES — {seq_label.upper()}',
                _style('bul', fontSize=12, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, textColor=BLEU,
                       borderPad=3, borderColor=BLEU, borderWidth=1))],
            [Paragraph(f'Année scolaire {annee}',
                _style('yr', fontSize=9, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, textColor=OR_FONCE))],
        ]
        centre = Table(centre_data, colWidths=[W - 2*1.2*cm - 2*2.2*cm])
        centre.setStyle(TableStyle([('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1)]))

        # QR info
        qr_data = [
            [qr_img],
            [Paragraph('📲 Scan pour\nbulletin numérique',
                _style('qs', fontSize=6, alignment=TA_CENTER, textColor=GRIS))],
            [Paragraph(el['matricule'],
                _style('qm', fontSize=6, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, textColor=BLEU_FONCE))],
        ]
        qr_table = Table(qr_data, colWidths=[2.2*cm])
        qr_table.setStyle(TableStyle([('ALIGN',(0,0),(-1,-1),'CENTER'),
                                       ('TOPPADDING',(0,0),(-1,-1),1),
                                       ('BOTTOMPADDING',(0,0),(-1,-1),1)]))

        main = Table([[logo_cell, centre, qr_table]],
                     colWidths=[2.2*cm, W - 2*1.2*cm - 2*2.2*cm, 2.2*cm])
        main.setStyle(TableStyle([
            ('VALIGN', (0,0),(-1,-1), 'MIDDLE'),
            ('ALIGN',  (0,0),(0,-1),  'CENTER'),
            ('ALIGN',  (2,0),(2,-1),  'CENTER'),
            ('LINEBELOW', (0,0),(-1,-1), 1.5, BLEU_FONCE),
            ('TOPPADDING', (0,0),(-1,-1), 2),
            ('BOTTOMPADDING', (0,0),(-1,-1), 4),
        ]))
        return main

    # ── BLOC 2 — INFOS ÉLÈVE ──────────────────────────────────────────────────
    def _infos_eleve(self, el, cls, bul):
        s = _style
        lbl = lambda t: Paragraph(t, s('l', fontSize=7, textColor=GRIS))
        val = lambda t: Paragraph(str(t), s('v', fontSize=8.5, fontName='Helvetica-Bold'))

        data = [
            [lbl('Nom & Prénom(s)'),      val(f"{el['nom']} {el['prenom']}"),
             lbl('Classe'),               val(cls.get('nom','—')),
             lbl('Photo'),                ''],
            [lbl('Matricule MINSEC'),     val(el.get('matricule','—')),
             lbl('Section'),              val('Francophone' if el.get('section')=='fr' else 'Anglophone'),
             '', ''],
            [lbl('Date & lieu naiss.'),   val(f"{_fmt_date(el.get('date_naiss'))} à {el.get('lieu_naiss','—')}"),
             lbl('Titulaire de classe'),  val(cls.get('titulaire','—')),
             '', ''],
            [lbl('Père / Tuteur'),        val(el.get('nom_pere','—')),
             lbl('Effectif classe'),      val(f"{bul.get('total',42)} élèves"),
             '', ''],
        ]

        t = Table(data, colWidths=[2.8*cm, 5.5*cm, 2.8*cm, 5.0*cm, 1.2*cm, 2.0*cm],
                  rowHeights=[0.9*cm]*4)
        t.setStyle(TableStyle([
            ('BACKGROUND',   (0,0),(-1,-1), BLEU_CLAIR),
            ('BACKGROUND',   (0,0),(0,-1), colors.HexColor('#DDEEFF')),
            ('BACKGROUND',   (2,0),(2,-1), colors.HexColor('#DDEEFF')),
            ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
            ('GRID',         (0,0),(-1,-1), 0.3, BLEU_MED),
            ('SPAN',         (4,0),(5,-1)),
            ('BACKGROUND',   (4,0),(5,-1), GRIS_CL),
            ('TOPPADDING',   (0,0),(-1,-1), 2),
            ('BOTTOMPADDING',(0,0),(-1,-1), 2),
            ('LEFTPADDING',  (0,0),(-1,-1), 4),
        ]))
        return t

    # ── BLOC 3 — TABLEAU NOTES APC ────────────────────────────────────────────
    def _tableau_notes(self, notes, section='fr'):
        s = _style
        mats = MATIERES_LYCEE if any(n.get('lycee') for n in notes) else MATIERES_COLLEGE

        # En-tête
        header = [
            Paragraph('Domaine APC', s('h', fontSize=7, fontName='Helvetica-Bold',
                                       alignment=TA_LEFT, textColor=BLANC)),
            Paragraph('Matière / Discipline', s('h', fontSize=7, fontName='Helvetica-Bold',
                                                alignment=TA_LEFT, textColor=BLANC)),
            Paragraph('C', s('h', fontSize=7, fontName='Helvetica-Bold',
                             alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Seq 1\n/20', s('h', fontSize=6.5, fontName='Helvetica-Bold',
                                       alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Seq 2\n/20', s('h', fontSize=6.5, fontName='Helvetica-Bold',
                                       alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Note\n/20', s('h', fontSize=7, fontName='Helvetica-Bold',
                                     alignment=TA_CENTER, textColor=colors.HexColor('#FFD54F'))),
            Paragraph('×Coef', s('h', fontSize=6.5, fontName='Helvetica-Bold',
                                  alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Moy\nTrim.', s('h', fontSize=6.5, fontName='Helvetica-Bold',
                                       alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Appréciation', s('h', fontSize=7, fontName='Helvetica-Bold',
                                        alignment=TA_CENTER, textColor=BLANC)),
            Paragraph('Professeur', s('h', fontSize=6.5, fontName='Helvetica-Bold',
                                       alignment=TA_CENTER, textColor=BLANC)),
        ]

        rows  = [header]
        style_cmds = [
            ('BACKGROUND',   (0,0),(-1,0), BLEU_FONCE),
            ('TEXTCOLOR',    (0,0),(-1,0), BLANC),
            ('FONTNAME',     (0,0),(-1,0), 'Helvetica-Bold'),
            ('FONTSIZE',     (0,0),(-1,0), 7),
            ('ALIGN',        (0,0),(-1,0), 'CENTER'),
            ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
            ('ROWBACKGROUNDS',(0,1),(-1,-1), [BLANC, BLEU_CLAIR]),
            ('GRID',         (0,0),(-1,-1), 0.3, colors.HexColor('#BBDEFB')),
            ('TOPPADDING',   (0,0),(-1,-1), 2),
            ('BOTTOMPADDING',(0,0),(-1,-1), 2),
            ('LEFTPADDING',  (0,0),(-1,-1), 3),
            ('RIGHTPADDING', (0,0),(-1,-1), 3),
        ]

        # Regrouper par domaine
        domaine_courant = None
        dom_start = 1
        total_pts = 0
        total_coef = 0

        for i, m in enumerate(mats):
            # Ligne de domaine si changement
            if m['dom'] != domaine_courant:
                if domaine_courant is not None:
                    # Fin du domaine précédent — ligne séparatrice
                    pass
                domaine_courant = m['dom']
                dom_row = [
                    Paragraph(f"● {m['dom']}", s('dom', fontSize=7,
                        fontName='Helvetica-Bold', textColor=BLEU_FONCE)),
                    '','','','','','','','',''
                ]
                rows.append(dom_row)
                r = len(rows) - 1
                style_cmds += [
                    ('SPAN',       (0,r),(-1,r)),
                    ('BACKGROUND', (0,r),(-1,r), colors.HexColor('#DDEEFF')),
                    ('LINEABOVE',  (0,r),(-1,r), 0.5, BLEU),
                ]

            # Données de la matière
            nd = next((n for n in notes if n.get('mat') == m['mat']), None)
            note_val = nd['note'] if nd else None
            s1 = nd.get('seq1', '—') if nd else '—'
            s2 = nd.get('seq2', '—') if nd else '—'
            coef = m['c']
            pts  = round(note_val * coef, 1) if note_val is not None else '—'
            moy_t = round((nd.get('seq1_val',0)+nd.get('seq2_val',0))/2,1) if nd else '—'
            appr  = _appreciation(note_val)
            prof  = nd.get('prof','—') if nd else '—'

            if isinstance(pts, float): total_pts += pts
            total_coef += coef

            nc = _couleur_note(note_val)
            row = [
                '',  # domaine (colonne fusionnée ci-dessus)
                Paragraph(m['mat'], s('mn', fontSize=7.5, leftIndent=8)),
                Paragraph(str(coef), s('c', fontSize=8, fontName='Helvetica-Bold',
                                       alignment=TA_CENTER)),
                Paragraph(str(s1), s('n', fontSize=8, alignment=TA_CENTER)),
                Paragraph(str(s2), s('n', fontSize=8, alignment=TA_CENTER)),
                Paragraph(f"{note_val:.1f}" if note_val else '—',
                    s('nv', fontSize=9, fontName='Helvetica-Bold',
                      alignment=TA_CENTER, textColor=nc)),
                Paragraph(f"{pts}" if isinstance(pts, float) else '—',
                    s('pts', fontSize=8, fontName='Helvetica-Bold', alignment=TA_CENTER)),
                Paragraph(f"{moy_t}" if isinstance(moy_t, float) else '—',
                    s('mt', fontSize=8, alignment=TA_CENTER)),
                Paragraph(appr, s('ap', fontSize=7, alignment=TA_CENTER,
                    textColor=VERT if note_val and note_val>=10 else ROUGE if note_val and note_val<8 else ORANGE)),
                Paragraph(prof, s('pr', fontSize=6.5, alignment=TA_CENTER, textColor=GRIS)),
            ]
            rows.append(row)

        # Ligne TOTAL
        moy_gen = round(total_pts/total_coef, 2) if total_coef else 0
        rows.append([
            Paragraph('TOTAL GÉNÉRAL', s('tot', fontSize=8, fontName='Helvetica-Bold',
                                         textColor=BLANC)),
            '',
            Paragraph(str(total_coef), s('tc', fontSize=8, fontName='Helvetica-Bold',
                                          alignment=TA_CENTER, textColor=BLANC)),
            '','',
            Paragraph(f"{total_pts:.1f}", s('tp', fontSize=8.5, fontName='Helvetica-Bold',
                                             alignment=TA_CENTER, textColor=OR)),
            '','','','',
        ])
        r_tot = len(rows)-1
        style_cmds += [
            ('BACKGROUND', (0,r_tot),(-1,r_tot), BLEU_FONCE),
            ('TEXTCOLOR',  (0,r_tot),(-1,r_tot), BLANC),
            ('SPAN',       (0,r_tot),(1,r_tot)),
            ('SPAN',       (3,r_tot),(9,r_tot)),
        ]

        # Ligne MOYENNE
        dec_txt, dec_col = _decision(moy_gen)
        rows.append([
            Paragraph('MOYENNE GÉNÉRALE / 20', s('mg', fontSize=9, fontName='Helvetica-Bold',
                                                  textColor=BLANC)),
            '',
            Paragraph(f"{moy_gen:.2f}", s('mgv', fontSize=12, fontName='Helvetica-Bold',
                                           alignment=TA_CENTER, textColor=OR)),
            '',
            Paragraph(_mention(moy_gen), s('men', fontSize=9, fontName='Helvetica-Bold',
                                            alignment=TA_CENTER, textColor=OR)),
            '',
            Paragraph(dec_txt, s('dec', fontSize=10, fontName='Helvetica-Bold',
                                  alignment=TA_CENTER, textColor=BLANC)),
            '','','',
        ])
        r_moy = len(rows)-1
        style_cmds += [
            ('BACKGROUND', (0,r_moy),(-1,r_moy), dec_col),
            ('SPAN',       (0,r_moy),(1,r_moy)),
            ('SPAN',       (2,r_moy),(3,r_moy)),
            ('SPAN',       (3,r_moy),(4,r_moy)),
            ('SPAN',       (5,r_moy),(5,r_moy)),
            ('SPAN',       (6,r_moy),(9,r_moy)),
            ('FONTSIZE',   (0,r_moy),(-1,r_moy), 9),
        ]

        col_w = [2.4*cm, 5.0*cm, 0.6*cm, 1.1*cm, 1.1*cm, 1.2*cm, 1.1*cm, 1.1*cm, 2.2*cm, 2.0*cm]
        t = Table(rows, colWidths=col_w)
        t.setStyle(TableStyle(style_cmds))

        # Titre section
        titre = Table([[Paragraph('RÉSULTATS PAR DOMAINE ET PAR MATIÈRE — APPROCHE PAR COMPÉTENCES (APC)',
            _style('tt', fontSize=7.5, fontName='Helvetica-Bold', textColor=BLANC,
                   alignment=TA_LEFT))]],
            colWidths=[sum(col_w)])
        titre.setStyle(TableStyle([
            ('BACKGROUND', (0,0),(-1,-1), BLEU),
            ('TOPPADDING', (0,0),(-1,-1), 4),
            ('BOTTOMPADDING',(0,0),(-1,-1), 4),
            ('LEFTPADDING', (0,0),(-1,-1), 6),
        ]))
        return KeepTogether([titre, t])

    # ── BLOC 4 — SYNTHÈSE ─────────────────────────────────────────────────────
    def _synthese(self, bul, notes):
        s = _style
        moy   = bul.get('moyenne', 0)
        rang  = bul.get('rang', '—')
        total = bul.get('total', 42)
        h_abs = bul.get('h_absences', 0)
        h_jus = bul.get('h_justifiees', 0)
        dec_txt, dec_col = _decision(moy)

        rang_txt = f"{rang}er / {total}" if rang==1 else f"{rang}e / {total}"
        sub_dec  = ('Classe supérieure' if moy>=10 else 'Rachat accordé' if moy>=8 else 'Redoublement')

        data = [[
            Paragraph(f"MOY.\n{moy:.2f}/20",
                s('mv', fontSize=14, fontName='Helvetica-Bold', textColor=OR, alignment=TA_CENTER)),
            Paragraph(f"RANG\n{rang_txt}",
                s('rv', fontSize=11, fontName='Helvetica-Bold', alignment=TA_CENTER, textColor=OR_FONCE)),
            Paragraph(f"ABSENCES\n{h_abs}h  (just.: {h_jus}h)",
                s('av', fontSize=9, fontName='Helvetica-Bold', alignment=TA_CENTER, textColor=ROUGE)),
            Paragraph(f"DÉCISION\n{dec_txt}\n{sub_dec}",
                s('dv', fontSize=10, fontName='Helvetica-Bold', textColor=BLANC, alignment=TA_CENTER)),
        ]]

        outer = Table(data, colWidths=[4*cm, 3.5*cm, 3.5*cm, 3.5*cm], rowHeights=[2*cm])
        outer.setStyle(TableStyle([
            ('BACKGROUND',   (0,0),(0,0), BLEU_FONCE),
            ('BACKGROUND',   (1,0),(1,0), colors.HexColor('#FFF9C4')),
            ('BACKGROUND',   (2,0),(2,0), colors.HexColor('#FFEBEE')),
            ('BACKGROUND',   (3,0),(3,0), dec_col),
            ('VALIGN',       (0,0),(-1,-1), 'MIDDLE'),
            ('ALIGN',        (0,0),(-1,-1), 'CENTER'),
            ('GRID',         (0,0),(-1,-1), 0.5, BLANC),
            ('TOPPADDING',   (0,0),(-1,-1), 6),
            ('BOTTOMPADDING',(0,0),(-1,-1), 6),
        ]))
        return outer

    # ── BLOC 5 — APPRÉCIATIONS & DISCIPLINE ──────────────────────────────────
    def _appreciations(self, bul):
        s = _style

        def box(titre, contenu, bg=BLANC):
            return Table([
                [Paragraph(titre, s('bt', fontSize=7.5, fontName='Helvetica-Bold',
                                    textColor=BLEU_FONCE))],
                [Paragraph(contenu, s('bc', fontSize=8, textColor=GRIS_F, leading=11))],
            ], colWidths=[(W-2*1.2*cm)/2 - 3*mm],
            rowHeights=[0.6*cm, 1.4*cm])

        apprec_dir  = bul.get('apprec_dir', 'Bons résultats. Continuez vos efforts.')
        apprec_tit  = bul.get('apprec_tit', 'Élève sérieux(se). Bonne participation.')
        apprec_surv = bul.get('apprec_surv', 'Comportement respectueux. Aucune sanction.')
        conduite    = bul.get('conduite', 'Bien')

        acad = box('📚 APPRÉCIATION DU DIRECTEUR DES ÉTUDES', apprec_dir, BLEU_CLAIR)
        tit  = box('👨‍🏫 APPRÉCIATION DU TITULAIRE DE CLASSE', apprec_tit, BLANC)
        disc = box('🛡️ CONDUITE & DISCIPLINE — Surveillant Général',
                   f"Conduite: {conduite}. {apprec_surv}", colors.HexColor('#FFF3E0'))
        paren = box('👪 OBSERVATIONS DES PARENTS / TUTEURS',
                    'Lu et approuvé. Signature obligatoire.', GRIS_CL)

        style_box = TableStyle([
            ('BACKGROUND',   (0,0),(-1,0), colors.HexColor('#DDEEFF')),
            ('BACKGROUND',   (0,1),(-1,1), BLANC),
            ('BOX',          (0,0),(-1,-1), 0.5, BLEU_MED),
            ('TOPPADDING',   (0,0),(-1,-1), 3),
            ('BOTTOMPADDING',(0,0),(-1,-1), 3),
            ('LEFTPADDING',  (0,0),(-1,-1), 5),
        ])
        for b in [acad, tit, disc, paren]:
            b.setStyle(style_box)

        outer = Table([[acad, tit], [disc, paren]],
                      colWidths=[(W-2*1.2*cm)/2]*2,
                      rowHeights=[2.5*cm, 2.5*cm])
        outer.setStyle(TableStyle([
            ('VALIGN', (0,0),(-1,-1), 'TOP'),
            ('TOPPADDING', (0,0),(-1,-1), 2),
            ('LEFTPADDING', (0,0),(-1,-1), 2),
            ('RIGHTPADDING', (0,0),(-1,-1), 2),
        ]))
        return outer

    # ── BLOC 6 — SIGNATURES ───────────────────────────────────────────────────
    def _signatures(self, cls, annee):
        s = _style

        def sign_box(titre, nom, role):
            return [
                Paragraph(titre, s('st', fontSize=7.5, fontName='Helvetica-Bold',
                                   textColor=BLEU_FONCE, alignment=TA_CENTER)),
                Spacer(1, 0.8*cm),  # espace pour la signature manuscrite
                HRFlowable(width='90%', thickness=0.5, color=GRIS),
                Paragraph(nom, s('sn', fontSize=7, fontName='Helvetica-Bold',
                                 alignment=TA_CENTER, textColor=GRIS_F)),
                Paragraph(role, s('sr', fontSize=6, textColor=GRIS, alignment=TA_CENTER)),
            ]

        cw = (W - 2*1.2*cm) / 4

        signs = [
            sign_box('🏛️ LE PRINCIPAL', 'M. OWONA MBARGA M.P.', 'Principal du Collège'),
            sign_box('📚 DIRECTEUR DES ÉTUDES', cls.get('dir_etudes', 'Mme ONANA Marie'),
                     'Dir. Études — Section FR'),
            sign_box('👨‍🏫 TITULAIRE DE CLASSE', cls.get('titulaire', 'M. ESSAMA Paul'),
                     f"Titulaire — {cls.get('nom','6ème A')}"),
            sign_box('👪 SIGNATURE PARENT/TUTEUR', 'Père / Mère / Tuteur', 'Lu et approuvé'),
        ]

        cols = [[s_item] for s_item in signs]

        # Construction du tableau 4 colonnes
        rows_data = []
        max_rows = max(len(c) for c in cols)
        for ri in range(max_rows):
            row = []
            for ci, col_items in enumerate(cols):
                row.append(col_items[ri] if ri < len(col_items) else '')
            rows_data.append(row)

        t = Table(rows_data, colWidths=[cw]*4)
        t.setStyle(TableStyle([
            ('VALIGN',       (0,0),(-1,-1), 'TOP'),
            ('ALIGN',        (0,0),(-1,-1), 'CENTER'),
            ('TOPPADDING',   (0,0),(-1,-1), 3),
            ('BOTTOMPADDING',(0,0),(-1,-1), 3),
            ('GRID',         (0,0),(-1,-1), 0.3, BLEU_MED),
            ('BACKGROUND',   (0,0),(-1,0), BLEU_CLAIR),
            ('LINEABOVE',    (0,0),(-1,0), 1.5, BLEU_FONCE),
        ]))
        return t

    # ── BLOC 7 — PIED DE PAGE ─────────────────────────────────────────────────
    def _pied_de_page(self, el, seq, annee):
        s = _style
        num_bul = f"CBLP/{el['matricule']}/S{seq}/{annee.replace('-','')}"
        texte = (f"COLLÈGE BILINGUE LA PENSÉE  ·  N° Bulletin: {num_bul}  ·  "
                 f"Année scolaire {annee}  ·  "
                 f"© Conçu par OWONA MBARGA MATHIEU PATRICK — Ingénieur Informatique "
                 f"· +237 691 105 604")
        t = Table([[Paragraph(texte, s('fp', fontSize=6, textColor=BLANC,
                                       alignment=TA_CENTER))]],
                  colWidths=[W - 2*1.2*cm])
        t.setStyle(TableStyle([
            ('BACKGROUND',   (0,0),(-1,-1), BLEU_FONCE),
            ('TOPPADDING',   (0,0),(-1,-1), 4),
            ('BOTTOMPADDING',(0,0),(-1,-1), 4),
        ]))
        return t


# ── GÉNÉRATION EN MASSE ───────────────────────────────────────────────────────

def generer_bulletins_classe(classe_id: int, sequence: int, db_path: str,
                              output_dir: str = 'static/bulletins') -> list:
    """
    Génère les bulletins PDF de toute une classe pour une séquence donnée.
    Retourne la liste des chemins PDF générés.
    """
    import random
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Infos classe
    c.execute("SELECT * FROM classes WHERE id=?", (classe_id,))
    cls_row = c.fetchone()
    if not cls_row:
        conn.close()
        return []
    cls = dict(cls_row)

    # Élèves de la classe
    c.execute("SELECT * FROM eleves WHERE classe_id=? ORDER BY nom,prenom", (classe_id,))
    eleves = [dict(r) for r in c.fetchall()]

    # Matières avec notes
    c.execute("""
        SELECT m.nom_fr as mat, m.coef_fr as c, u.nom||' '||u.prenom as prof,
               n.note, n.appreciation
        FROM matieres m
        LEFT JOIN notes n ON n.matiere_id=m.id AND n.classe_id=? AND n.sequence=?
        LEFT JOIN attributions a ON a.matiere_id=m.id AND a.classe_id=?
        LEFT JOIN utilisateurs u ON a.prof_id=u.id
        WHERE m.section IN ('fr','both')
        ORDER BY m.id
    """, (classe_id, sequence, classe_id))
    mats_global = [dict(r) for r in c.fetchall()]
    conn.close()

    gen = BulletinPDF(output_dir)
    pdfs = []
    moyennes = []

    # Calcul des moyennes pour le classement
    for el in eleves:
        mats_el = []
        total_pts = 0
        total_coef = 0
        for mat in MATIERES_COLLEGE:
            note_val = round(random.uniform(7, 19), 1)  # Remplacer par vraies notes en prod
            total_pts += note_val * mat['c']
            total_coef += mat['c']
            mats_el.append({**mat, 'note': note_val,
                             'seq1': note_val, 'seq2': round(note_val+random.uniform(-2,2),1),
                             'seq1_val': note_val,
                             'seq2_val': round(note_val+random.uniform(-2,2),1),
                             'prof': '—'})
        moy = round(total_pts/total_coef, 2)
        moyennes.append((el['id'], moy))

    # Classement
    moyennes.sort(key=lambda x: -x[1])
    rangs = {eid: i+1 for i, (eid, _) in enumerate(moyennes)}

    for el in eleves:
        moy = dict(moyennes).get(el['id'], 0) if moyennes else 0
        # Reconstituer les notes pour cet élève
        import random as rnd
        rnd.seed(el['id'] * sequence * 13)
        mats_el = []
        tp = 0; tc = 0
        for mat in MATIERES_COLLEGE:
            n = round(rnd.uniform(7,19),1)
            tp += n*mat['c']; tc += mat['c']
            mats_el.append({**mat,'note':n,'seq1':n,'seq2':round(n+rnd.uniform(-2,2),1),
                             'seq1_val':n,'seq2_val':round(n+rnd.uniform(-2,2),1),'prof':'Prof.'})
        moy_el = round(tp/tc,2)

        data = {
            'eleve': el,
            'classe': {**cls, 'titulaire': 'M. ESSAMA Paul', 'dir_etudes': 'Mme ONANA Marie'},
            'sequence': sequence,
            'notes': mats_el,
            'bulletin': {
                'moyenne': moy_el,
                'rang': rangs.get(el['id'], '—'),
                'total': len(eleves),
                'h_absences': round(rnd.uniform(0,6),0),
                'h_justifiees': 0,
                'decision': 'ADMIS' if moy_el>=10 else 'RACHAT' if moy_el>=8 else 'ECHEC',
                'apprec_dir': 'Bons résultats. Persévérez dans vos efforts.',
                'apprec_tit': 'Élève appliqué(e) et sérieux(se). Continuez.',
                'apprec_surv': 'Bonne conduite. Aucune sanction disciplinaire.',
                'conduite': 'Très bien',
            },
            'annee': '2024-2025',
            'section': cls['section'],
        }
        pdf = gen.generer_bulletin(data)
        pdfs.append(pdf)

    print(f"[CBLP] {len(pdfs)} bulletins générés pour la classe {cls['nom']}")
    return pdfs


# ── TEST DIRECT ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))

    # Données de test
    eleve_test = {
        'id': 3,
        'matricule': 'CBLP-2025-0003',
        'nom': 'BIYONG',
        'prenom': 'Sylvie Rose',
        'date_naiss': '2012-01-22',
        'lieu_naiss': 'Douala',
        'sexe': 'F',
        'section': 'fr',
        'nom_pere': 'BIYONG Marc',
        'nom_mere': 'BIYONG Claire',
        'tel_tuteur': '699 111 003',
    }
    classe_test = {
        'id': 1, 'code': '6A', 'nom': 'Sixième A',
        'niveau': 'college', 'section': 'fr', 'salle': 'A101',
        'eff_max': 50, 'titulaire': 'M. ESSAMA Paul',
        'dir_etudes': 'Mme ONANA Marie',
    }
    import random; random.seed(42)
    notes_test = []
    for m in MATIERES_COLLEGE:
        n = round(random.uniform(9, 19), 1)
        notes_test.append({
            **m,
            'note': n,
            'seq1': n,
            'seq2': round(n + random.uniform(-2, 2), 1),
            'seq1_val': n,
            'seq2_val': round(n + random.uniform(-2, 2), 1),
            'prof': 'M. FOMEKONG',
        })
    tp = sum(n['note']*n['c'] for n in notes_test)
    tc = sum(n['c'] for n in notes_test)
    moy = round(tp/tc, 2)

    data_test = {
        'eleve': eleve_test,
        'classe': classe_test,
        'sequence': 1,
        'notes': notes_test,
        'bulletin': {
            'moyenne': moy, 'rang': 2, 'total': 42,
            'h_absences': 2, 'h_justifiees': 2,
            'decision': 'ADMIS',
            'apprec_dir': 'Très bons résultats. Élève de grande valeur. Continuez sur cette lancée!',
            'apprec_tit': 'Élève sérieuse, assidue et participative. Félicitations!',
            'apprec_surv': 'Comportement exemplaire. Aucune sanction disciplinaire enregistrée.',
            'conduite': 'Très bien',
        },
        'annee': '2024-2025',
        'section': 'fr',
    }

    os.makedirs('static/bulletins', exist_ok=True)
    gen = BulletinPDF('static/bulletins')
    pdf_path = gen.generer_bulletin(data_test)
    print(f"\n✅ Bulletin généré : {pdf_path}")
    print(f"   Élève  : {eleve_test['nom']} {eleve_test['prenom']}")
    print(f"   Classe : {classe_test['nom']}")
    print(f"   Moyenne: {moy}/20")
