# COLLÈGE BILINGUE LA PENSÉE — Système de Gestion Scolaire
## Version 3.0 — Backend Flask + PDF ReportLab + SQLite

**Conçu par : OWONA MBARGA MATHIEU PATRICK**
**Ingénieur en Informatique — Analyste Programmeur & Testeur d'Applications**
**Tél : +237 691 105 604 / +237 671 659 226**

---

## 📦 STRUCTURE DU PROJET

```
cblp_full/
├── server.py           ← Backend Flask (API REST + serveur web)
├── db_init.py          ← Initialisation base de données SQLite
├── bulletin_pdf.py     ← Génération PDF bulletins (norme APC MINESEC)
├── index_v3.html       ← Application frontend (interface complète)
├── db/
│   └── cblp.db         ← Base de données SQLite (générée auto)
├── static/
│   ├── bulletins/      ← Bulletins PDF générés
│   ├── cartes/         ← Cartes scolaires générées
│   └── uploads/        ← Photos, images, documents uploadés
└── README.md
```

---

## 🚀 INSTALLATION RAPIDE

### 1. Prérequis Python
```bash
python3 --version   # Python 3.8+ requis
```

### 2. Installer les dépendances
```bash
pip install flask reportlab Pillow qrcode
```

### 3. Initialiser la base de données
```bash
python3 db_init.py
```

### 4. Lancer le serveur
```bash
python3 server.py
```

### 5. Ouvrir l'application
- **Local** : http://localhost:5000
- **Réseau local** : http://[IP-du-PC]:5000
- **Depuis un téléphone (même WiFi)** : http://[IP-du-PC]:5000

---

## 🔐 COMPTES PAR DÉFAUT

| Rôle | Email | Mot de passe |
|------|-------|-------------|
| Super Admin (IT) | it@cblp.cm | admin123 |
| Principal | principale@cblp.cm | princ123 |
| Vice-Principal | vprincipale@cblp.cm | vp123 |
| Directeur FR | dir.fr@cblp.cm | dir123 |
| Directeur EN | dir.en@cblp.cm | dir123 |
| Censeur | censeur@cblp.cm | cens123 |
| Surveillant Gén. 1 | sg1@cblp.cm | sg123 |
| Surveillant Gén. 2 | sg2@cblp.cm | sg123 |
| Secrétaire | secretaire@cblp.cm | sec123 |
| Professeur | fomekong@cblp.cm | prof123 |

> ⚠️ **IMPORTANT** : Changer tous les mots de passe après la première connexion !

---

## 📋 MODULES DISPONIBLES

1. **Tableau de bord** — Statistiques globales, alertes, agenda
2. **Inscriptions** — Formulaire complet, matricule MINSEC auto-généré
3. **Classes** — FR (6ème→Tle) + EN (Form 1→Upper Sixth)
4. **Élèves** — Liste complète avec filtres, export PDF
5. **Notes & Bulletins APC** — Saisie, calcul, classement, PDF
6. **Absences** — Feuille de présence interactive
7. **Statistiques** — Résultats par séquence (1-6), trimestre, annuel
8. **Emplois du temps** — Planning hebdomadaire
9. **Cartes scolaires** — Génération avec matricule MINSEC
10. **Certificats de scolarité** — Documents officiels
11. **Babillard** — Publications images/vidéos/PDF
12. **Professeurs** — Gestion, attribution classes/matières
13. **Personnel admin** — Principal, Vice-Principal, Censeur, Surveillants, Secrétaire
14. **Matières APC** — 26 matières selon norme MINESEC (tous domaines)
15. **Examens officiels** — BEPC, BAC, GCE O/A-Level
16. **Fêtes & Chronogramme** — Calendrier officiel
17. **Comptes & Accès** — Validation IT uniquement

---

## 📄 BULLETIN PDF — NORME APC CAMEROUN

Le module `bulletin_pdf.py` génère des bulletins conformes au programme APC MINESEC :

- **En-tête officiel** : République du Cameroun, MINESEC, nom de l'établissement
- **QR Code unique** : Renvoie vers le bulletin numérique en ligne
- **Domaines APC** : Langages, Mathématiques, Sciences, Humanités, Technologie, Arts, Santé
- **Colonnes** : Note/20, Coef, Séq1, Séq2, Moy×Coef, Moy Trim, Appréciation, Professeur
- **Appréciations** : Directeur des Études + Titulaire de classe
- **Discipline** : Surveillant Général (conduite, sanctions)
- **4 Signatures** : Principal, Directeur des Études, Titulaire, Parent
- **Synthèse** : Moyenne, Rang, Absences, Décision (ADMIS/RACHAT/ÉCHEC)
- **Pied de page** : Numéro unique du bulletin, signature du concepteur

---

## 🌐 API REST — ENDPOINTS PRINCIPAUX

```
POST /api/login                         Connexion
POST /api/logout                        Déconnexion
GET  /api/me                            Profil utilisateur
GET  /api/utilisateurs                  Liste des utilisateurs
POST /api/utilisateurs                  Créer un utilisateur
POST /api/utilisateurs/{id}/valider     Valider un compte
POST /api/utilisateurs/{id}/suspendre   Suspendre un compte
GET  /api/classes                       Liste des classes
POST /api/classes                       Créer une classe
GET  /api/eleves                        Liste des élèves (filtres)
POST /api/eleves                        Inscrire un élève
GET  /api/eleves/{id}                   Fiche d'un élève
PUT  /api/eleves/{id}                   Modifier la fiche élève
GET  /api/matieres                      Liste des matières APC
GET  /api/domaines                      Domaines APC
GET  /api/notes                         Notes d'une classe/séquence
POST /api/notes/saisie                  Saisir les notes
GET  /api/notes/classement/{cls}/{seq}  Classement d'une classe
GET  /api/bulletins/generer/{id}/{seq}  PDF bulletin d'un élève
GET  /api/bulletins/classe/{cls}/{seq}  PDF toute une classe
GET  /api/absences                      Liste des absences
POST /api/absences                      Saisir les absences
GET  /api/stats/dashboard               Statistiques générales
GET  /api/stats/resultats               Résultats par classe
GET  /api/evenements                    Calendrier
POST /api/evenements                    Ajouter un événement
GET  /api/publications                  Babillard
POST /api/publications                  Publier
GET  /api/emplois                       Emplois du temps
POST /api/emplois                       Ajouter un cours
POST /api/upload/photo                  Uploader une photo
GET  /api/health                        Santé du serveur
```

---

## 📱 DÉPLOIEMENT EN LIGNE

### Option 1 — Serveur VPS (Linux Ubuntu)
```bash
# Installer nginx + gunicorn
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 server:app

# Configuration nginx (reverse proxy)
# Voir documentation : https://flask.palletsprojects.com/deploying/
```

### Option 2 — PythonAnywhere (gratuit)
```
1. Créer un compte sur pythonanywhere.com
2. Uploader tous les fichiers
3. Configurer le WSGI
4. L'app sera accessible sur votre-compte.pythonanywhere.com
```

### Option 3 — Railway / Render (cloud gratuit)
```
1. Créer un compte sur railway.app ou render.com
2. Connecter votre dépôt GitHub
3. Déploiement automatique
```

---

## 📱 VERSION ANDROID

La version Android utilise **Apache Cordova** ou **Capacitor** pour
encapsuler l'application web dans un APK Android.

```bash
# Installer Node.js et Cordova
npm install -g cordova

# Créer le projet Cordova
cordova create cblp-android com.cblp.app "CBLP Gestion"
cd cblp-android

# Ajouter la plateforme Android
cordova platform add android

# Copier l'interface dans www/
cp ../index_v3.html www/index.html

# Configurer l'URL du serveur dans config.xml
# Pour l'accès local en réseau: http://192.168.1.X:5000

# Générer l'APK
cordova build android

# L'APK se trouve dans:
# platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

Pour publication sur **Google Play Store** :
- Créer un compte développeur Google ($25 frais unique)
- Générer un APK signé : `cordova build android --release`
- Soumettre sur play.google.com/console

---

## ⚙️ CONFIGURATION AVANCÉE

Modifier la classe `Config` dans `server.py` :

```python
class Config:
    SECRET_KEY = 'votre-clé-secrète-unique'  # Changer en production!
    HOST       = '0.0.0.0'    # 0.0.0.0 = accessible réseau, 127.0.0.1 = local seulement
    PORT       = 5000
    DEBUG      = False         # True en développement, False en production
```

---

**© 2025 — COLLEGE BILINGUE LA PENSEE — Tous droits réservés**
**Concepteur : OWONA MBARGA MATHIEU PATRICK**
**Ingénieur en Informatique · +237 691 105 604 / +237 671 659 226**
