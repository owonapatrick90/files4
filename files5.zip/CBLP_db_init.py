"""
COLLEGE BILINGUE LA PENSEE
Module: Initialisation & gestion de la base de données SQLite
Auteur: OWONA MBARGA MATHIEU PATRICK — Ingénieur Informatique
"""
import sqlite3, hashlib, os, json
from datetime import datetime, date

DB_PATH = os.path.join(os.path.dirname(__file__), 'db', 'cblp.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def h(pwd): return hashlib.sha256(pwd.encode()).hexdigest()

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    c = conn.cursor()

    # ── UTILISATEURS ──────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS utilisateurs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        matricule   TEXT UNIQUE,
        nom         TEXT NOT NULL,
        prenom      TEXT NOT NULL,
        email       TEXT UNIQUE NOT NULL,
        pwd_hash    TEXT NOT NULL,
        role        TEXT NOT NULL,
        poste       TEXT,
        section     TEXT DEFAULT 'both',
        telephone   TEXT,
        photo       TEXT,
        statut      TEXT DEFAULT 'en_attente',
        derniere_connexion TEXT,
        date_creation TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    # ── CLASSES ───────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS classes (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        code        TEXT UNIQUE NOT NULL,
        nom         TEXT NOT NULL,
        niveau      TEXT NOT NULL,
        section     TEXT NOT NULL,
        division    TEXT,
        salle       TEXT,
        eff_max     INTEGER DEFAULT 50,
        titulaire_id INTEGER,
        annee       TEXT DEFAULT '2024-2025',
        FOREIGN KEY (titulaire_id) REFERENCES utilisateurs(id)
    )''')

    # ── ELEVES ────────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS eleves (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        matricule   TEXT UNIQUE NOT NULL,
        nom         TEXT NOT NULL,
        prenom      TEXT NOT NULL,
        date_naiss  TEXT,
        lieu_naiss  TEXT,
        sexe        TEXT,
        section     TEXT NOT NULL,
        classe_id   INTEGER,
        photo       TEXT,
        nom_pere    TEXT,
        nom_mere    TEXT,
        tel_tuteur  TEXT,
        adresse     TEXT,
        ancienne_ecole TEXT,
        frais_payes REAL DEFAULT 0,
        statut      TEXT DEFAULT 'inscrit',
        annee       TEXT DEFAULT '2024-2025',
        date_inscription TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (classe_id) REFERENCES classes(id)
    )''')

    # ── DOMAINES APC ──────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS domaines (
        id     INTEGER PRIMARY KEY AUTOINCREMENT,
        code   TEXT UNIQUE NOT NULL,
        nom_fr TEXT NOT NULL,
        nom_en TEXT,
        ordre  INTEGER DEFAULT 1
    )''')

    # ── MATIERES ──────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS matieres (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        domaine_id  INTEGER,
        code        TEXT UNIQUE NOT NULL,
        nom_fr      TEXT NOT NULL,
        nom_en      TEXT,
        coef_fr     INTEGER DEFAULT 1,
        coef_en     INTEGER DEFAULT 1,
        h_semaine   INTEGER DEFAULT 2,
        niveaux     TEXT DEFAULT 'all',
        section     TEXT DEFAULT 'both',
        FOREIGN KEY (domaine_id) REFERENCES domaines(id)
    )''')

    # ── ATTRIBUTIONS PROF → CLASSE → MATIÈRE ─────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS attributions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        prof_id     INTEGER NOT NULL,
        matiere_id  INTEGER NOT NULL,
        classe_id   INTEGER NOT NULL,
        annee       TEXT DEFAULT '2024-2025',
        FOREIGN KEY (prof_id)    REFERENCES utilisateurs(id),
        FOREIGN KEY (matiere_id) REFERENCES matieres(id),
        FOREIGN KEY (classe_id)  REFERENCES classes(id)
    )''')

    # ── NOTES ─────────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS notes (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        eleve_id    INTEGER NOT NULL,
        matiere_id  INTEGER NOT NULL,
        classe_id   INTEGER NOT NULL,
        sequence    INTEGER NOT NULL,
        trimestre   INTEGER,
        note        REAL,
        appreciation TEXT,
        saisie_par  INTEGER,
        annee       TEXT DEFAULT '2024-2025',
        date_saisie TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(eleve_id, matiere_id, sequence, annee),
        FOREIGN KEY (eleve_id)   REFERENCES eleves(id),
        FOREIGN KEY (matiere_id) REFERENCES matieres(id),
        FOREIGN KEY (classe_id)  REFERENCES classes(id)
    )''')

    # ── ABSENCES ──────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS absences (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        eleve_id    INTEGER NOT NULL,
        classe_id   INTEGER NOT NULL,
        date_abs    TEXT NOT NULL,
        heure_debut TEXT,
        heure_fin   TEXT,
        duree_h     REAL DEFAULT 2,
        justifiee   INTEGER DEFAULT 0,
        motif       TEXT,
        saisie_par  INTEGER,
        FOREIGN KEY (eleve_id)  REFERENCES eleves(id),
        FOREIGN KEY (classe_id) REFERENCES classes(id)
    )''')

    # ── EMPLOIS DU TEMPS ──────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS emplois_temps (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        classe_id   INTEGER NOT NULL,
        prof_id     INTEGER NOT NULL,
        matiere_id  INTEGER NOT NULL,
        jour        INTEGER NOT NULL,
        h_debut     TEXT NOT NULL,
        h_fin       TEXT NOT NULL,
        salle       TEXT,
        annee       TEXT DEFAULT '2024-2025',
        FOREIGN KEY (classe_id)  REFERENCES classes(id),
        FOREIGN KEY (prof_id)    REFERENCES utilisateurs(id),
        FOREIGN KEY (matiere_id) REFERENCES matieres(id)
    )''')

    # ── EVENEMENTS ────────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS evenements (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        titre       TEXT NOT NULL,
        description TEXT,
        date_debut  TEXT NOT NULL,
        date_fin    TEXT,
        type        TEXT,
        section     TEXT DEFAULT 'all',
        cree_par    INTEGER,
        FOREIGN KEY (cree_par) REFERENCES utilisateurs(id)
    )''')

    # ── PUBLICATIONS (BABILLARD) ──────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS publications (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        titre       TEXT NOT NULL,
        description TEXT,
        type        TEXT,
        fichier     TEXT,
        section     TEXT DEFAULT 'all',
        actif       INTEGER DEFAULT 1,
        publie_par  INTEGER,
        date_pub    TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (publie_par) REFERENCES utilisateurs(id)
    )''')

    # ── BULLETINS GENERES ─────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS bulletins (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        eleve_id    INTEGER NOT NULL,
        classe_id   INTEGER NOT NULL,
        sequence    INTEGER,
        trimestre   INTEGER,
        annee       TEXT DEFAULT '2024-2025',
        moyenne     REAL,
        rang        INTEGER,
        total_eleves INTEGER,
        h_absences  REAL DEFAULT 0,
        h_justifiees REAL DEFAULT 0,
        decision    TEXT,
        apprec_dir  TEXT,
        apprec_tit  TEXT,
        apprec_surv TEXT,
        conduite    TEXT DEFAULT 'Bien',
        pdf_path    TEXT,
        qr_code     TEXT,
        date_gen    TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (eleve_id)  REFERENCES eleves(id),
        FOREIGN KEY (classe_id) REFERENCES classes(id)
    )''')

    conn.commit()
    _seed(conn)
    conn.close()
    print(f"[CBLP] Base de données prête : {DB_PATH}")


def _seed(conn):
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM utilisateurs")
    if c.fetchone()[0] > 0:
        return

    # ── UTILISATEURS ──────────────────────────────────────────────────────────
    users = [
        ('IT-001','Informaticien','CBLP','it@cblp.cm',h('admin123'),'superadmin','Informaticien','both','699 000 001','actif'),
        (None,'OWONA MBARGA','Mathieu','principale@cblp.cm',h('princ123'),'principal','Principal du Collège','both','699 000 002','actif'),
        (None,'ESSONO','Claire','vprincipale@cblp.cm',h('vp123'),'vice_principal','Vice-Principal','both','699 000 003','actif'),
        (None,'ONANA','Marie','dir.fr@cblp.cm',h('dir123'),'directeur_fr','Directeur Études FR','fr','699 000 004','en_attente'),
        (None,'NKENG','Peter','dir.en@cblp.cm',h('dir123'),'directeur_en','Directeur Études EN','en','699 000 005','en_attente'),
        (None,'ATEBA','Sabine','censeur@cblp.cm',h('cens123'),'censeur','Censeur','both','699 000 006','actif'),
        (None,'MVONDO','Serge','sg1@cblp.cm',h('sg123'),'surveillant','Surveillant Général 1','both','699 000 007','actif'),
        (None,'BIYONG','Albert','sg2@cblp.cm',h('sg123'),'surveillant','Surveillant Général 2','both','699 000 008','actif'),
        (None,'NGONO','Patricia','secretaire@cblp.cm',h('sec123'),'secretaire','Secrétaire (Inscriptions)','both','699 000 009','actif'),
        (None,'FOMEKONG','Albert','fomekong@cblp.cm',h('prof123'),'professeur','Professeur','fr','699 111 001','actif'),
        (None,'ESSAMA','Paul','essama@cblp.cm',h('prof123'),'professeur','Professeur','fr','699 111 002','actif'),
        (None,'ATANGANA','Rose','atangana@cblp.cm',h('prof123'),'professeur','Professeur','fr','699 111 003','actif'),
        (None,'AGBOR','Grace','agbor@cblp.cm',h('prof123'),'professeur','Professeur','en','699 222 001','actif'),
        (None,'MBAH','John','mbah@cblp.cm',h('prof123'),'professeur','Professeur','en','699 222 002','actif'),
        (None,'FOUDA','Eric','fouda@cblp.cm',h('prof123'),'professeur','Professeur','both','699 111 004','actif'),
    ]
    for u in users:
        c.execute("""INSERT INTO utilisateurs (matricule,nom,prenom,email,pwd_hash,role,poste,section,telephone,statut)
            VALUES (?,?,?,?,?,?,?,?,?,?)""", u)

    # ── CLASSES FR ────────────────────────────────────────────────────────────
    cls_fr = [
        ('6A','Sixième A','college','fr','A','A101',50),
        ('6B','Sixième B','college','fr','B','A102',50),
        ('5A','Cinquième A','college','fr','A','B101',50),
        ('5B','Cinquième B','college','fr','B','B102',48),
        ('4A','Quatrième A','college','fr','A','C101',45),
        ('4B','Quatrième B','college','fr','B','C102',45),
        ('3A','Troisième A','college','fr','A','D101',45),
        ('3B','Troisième B','college','fr','B','D102',44),
        ('2A','Seconde A','lycee','fr','A','E101',40),
        ('2C','Seconde C','lycee','fr','C','E102',40),
        ('1A','Première A','lycee','fr','A','F101',38),
        ('1C','Première C','lycee','fr','C','F102',38),
        ('TleA','Terminale A','lycee','fr','A','G101',35),
        ('TleC','Terminale C','lycee','fr','C','G102',35),
    ]
    for cl in cls_fr:
        c.execute("INSERT INTO classes (code,nom,niveau,section,division,salle,eff_max) VALUES (?,?,?,?,?,?,?)", cl)

    # ── CLASSES EN ────────────────────────────────────────────────────────────
    cls_en = [
        ('F1A','Form One A','lower_sixth','en','A','H101',45),
        ('F2A','Form Two A','lower_sixth','en','A','H102',42),
        ('F3A','Form Three A','lower_sixth','en','A','I101',40),
        ('F4A','Form Four A','lower_sixth','en','A','I102',38),
        ('F5A','Form Five A','lower_sixth','en','A','J101',36),
        ('LSA','Lower Sixth A','upper_sixth','en','A','J102',28),
        ('LSSC','Lower Sixth Sci.','upper_sixth','en','SC','K101',25),
        ('USA','Upper Sixth A','upper_sixth','en','A','K102',22),
        ('USSC','Upper Sixth Sci.','upper_sixth','en','SC','L101',20),
    ]
    for cl in cls_en:
        c.execute("INSERT INTO classes (code,nom,niveau,section,division,salle,eff_max) VALUES (?,?,?,?,?,?,?)", cl)

    # ── DOMAINES APC ──────────────────────────────────────────────────────────
    domaines = [
        ('LANG','Langages & Communication','Languages & Communication',1),
        ('MATH','Mathématiques','Mathematics',2),
        ('SCI','Sciences de la Nature','Natural Sciences',3),
        ('SH','Sciences Humaines','Social Sciences',4),
        ('TECH','Technologie & Numérique','Technology & ICT',5),
        ('ART','Arts, Culture & Créativité','Arts & Culture',6),
        ('SANTE','Santé & Bien-être','Health & Well-being',7),
        ('GCE','GCE Subjects (EN)','GCE Subjects',8),
    ]
    for d in domaines:
        c.execute("INSERT INTO domaines (code,nom_fr,nom_en,ordre) VALUES (?,?,?,?)", d)

    # ── MATIERES APC ──────────────────────────────────────────────────────────
    mats = [
        # (domaine_id, code, nom_fr, nom_en, coef_fr, coef_en, h/sem, niveaux, section)
        (1,'FR','Langue Française','French',4,3,4,'Collège·Lycée','both'),
        (1,'EN','Langue Anglaise','English',3,4,3,'Collège·Lycée','both'),
        (1,'ALL','Allemand','German',2,2,2,'Lycée','fr'),
        (1,'ESP','Espagnol','Spanish',2,2,2,'Lycée','fr'),
        (2,'MATH','Mathématiques','Mathematics',5,5,4,'Collège·Lycée','both'),
        (3,'SVT','Sciences Vie & Terre','Biology/Life Sciences',3,3,2,'Collège·Lycée','both'),
        (3,'PHY','Physique-Chimie','Chemistry/Physics',3,3,3,'Collège·Lycée','both'),
        (3,'GEOPHYS','Géographie Physique','Physical Geography',2,2,1,'Lycée','both'),
        (4,'HG','Histoire-Géographie','History & Geography',2,2,2,'Collège·Lycée','both'),
        (4,'ECM','Éduc. Citoyenneté & Morale','Civic Education',2,2,1,'Collège','both'),
        (4,'PHILO','Philosophie','Philosophy',3,0,2,'Terminale','fr'),
        (4,'ECO','Économie Générale','Economics',2,3,2,'Lycée','both'),
        (4,'DROIT','Droit & Institutions','Law',2,0,1,'Lycée','fr'),
        (4,'BIBLE','Études Religieuses','Religious Studies/CRS',2,2,1,'Collège·Lycée','both'),
        (5,'INFO','Informatique','Computer Science/ICT',2,2,2,'Collège·Lycée','both'),
        (5,'TIC','TIC & Numérique','Digital Technology',1,1,1,'Collège','both'),
        (6,'ART','Éduc. Artistique & Musicale','Arts & Music',1,1,1,'Collège','both'),
        (6,'DESSIN','Dessin & Arts Plastiques','Fine Arts',1,1,1,'Collège','both'),
        (7,'EPS','Éduc. Physique & Sportive','Physical Education',1,1,2,'Collège·Lycée','both'),
        (3,'BIOCHIM','Biochimie','Biochemistry',3,3,2,'Terminale C/D','both'),
        (3,'GEOL','Géologie','Geology',2,2,1,'Terminale D','both'),
        (8,'LIT_EN','Literature in English','Literature in English',0,3,3,'Form4–US','en'),
        (8,'FURTHMATH','Further Mathematics','Further Mathematics',0,4,3,'Upper Sixth','en'),
        (8,'GEOG_EN','Geography','Geography',0,3,2,'Form1–US','en'),
        (8,'HIST_EN','History','History',0,3,2,'Form1–US','en'),
        (8,'COMM','Commerce','Commerce',0,3,2,'Form1–US','en'),
    ]
    for m in mats:
        c.execute("INSERT INTO matieres (domaine_id,code,nom_fr,nom_en,coef_fr,coef_en,h_semaine,niveaux,section) VALUES (?,?,?,?,?,?,?,?,?)", m)

    # ── ELEVES DEMO ───────────────────────────────────────────────────────────
    import random; random.seed(42)
    eleves = [
        ('CBLP-2025-0001','ABOMO','Marie Claire','2012-03-12','Yaoundé','F','fr',1,'ABOMO Pierre','ABOMO Jeanne','699 111 001'),
        ('CBLP-2025-0002','ATANGA','Jean Paul','2011-08-07','Bafoussam','M','fr',1,'ATANGA Louis','ATANGA Brigitte','699 111 002'),
        ('CBLP-2025-0003','BIYONG','Sylvie Rose','2012-01-22','Douala','F','fr',1,'BIYONG Marc','BIYONG Claire','699 111 003'),
        ('CBLP-2025-0004','EDIMA','Christian','2011-05-15','Sangmelima','M','fr',1,'EDIMA Joseph','EDIMA Anne','699 111 004'),
        ('CBLP-2025-0005','FOUDA','Nathalie','2012-07-30','Yaoundé','F','fr',1,'FOUDA Paul','FOUDA Marie','699 111 005'),
        ('CBLP-2025-0006','ESSONO','Patrick','2011-11-18','Bertoua','M','fr',1,'ESSONO Henri','ESSONO Sylvie','699 111 006'),
        ('CBLP-2025-0007','NKOLO','Cécile','2012-04-05','Ebolowa','F','fr',1,'NKOLO Robert','NKOLO Thérèse','699 111 007'),
        ('CBLP-2025-0008','MANGA','David','2011-09-23','Ngaoundéré','M','fr',1,'MANGA André','MANGA Christine','699 111 008'),
        ('CBLP-2025-0009','MVOGO','Rachel','2012-06-11','Yaoundé','F','fr',1,'MVOGO Pierre','MVOGO Anne','699 111 009'),
        ('CBLP-2025-0010','ONDO','Pascal','2011-12-03','Kribi','M','fr',1,'ONDO Jean','ONDO Marie','699 111 010'),
        ('CBLP-2025-0100','AGBOR','Lawrence','2011-06-15','Bamenda','M','en',15,'AGBOR Thomas','AGBOR Susan','699 222 001'),
        ('CBLP-2025-0101','FOMBU','Peter','2011-09-30','Buea','M','en',15,'FOMBU James','FOMBU Elizabeth','699 222 002'),
        ('CBLP-2025-0102','MBAH','Grace','2012-02-14','Limbe','F','en',15,'MBAH Paul','MBAH Dorothy','699 222 003'),
        ('CBLP-2025-0103','NKENG','Alice','2011-12-08','Kumba','F','en',15,'NKENG Francis','NKENG Margaret','699 222 004'),
    ]
    for e in eleves:
        c.execute("""INSERT INTO eleves (matricule,nom,prenom,date_naiss,lieu_naiss,sexe,section,classe_id,nom_pere,nom_mere,tel_tuteur)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""", e)

    # ── NOTES DEMO ────────────────────────────────────────────────────────────
    mat_ids_6A = [1,2,5,6,7,9,10,15,17,19,14]  # Matières collège
    for eleve_id in range(1, 11):
        for mat_id in mat_ids_6A:
            for seq in range(1, 7):
                note = round(random.uniform(7, 19), 1)
                appr = ('Très bien' if note>=15 else 'Bien' if note>=13 else
                        'Assez bien' if note>=10 else 'Insuffisant' if note>=8 else 'Très insuffisant')
                c.execute("""INSERT OR IGNORE INTO notes (eleve_id,matiere_id,classe_id,sequence,trimestre,note,appreciation)
                    VALUES (?,?,?,?,?,?,?)""",
                    (eleve_id, mat_id, 1, seq, (seq+1)//2, note, appr))

    # ── ABSENCES DEMO ─────────────────────────────────────────────────────────
    abs_data = [(1,1,'2025-01-13',2,1),(4,1,'2025-01-06',4,0),(4,1,'2025-01-07',4,0),
                (4,1,'2025-01-08',2,0),(6,1,'2025-01-09',2,1),(7,1,'2025-01-10',6,0)]
    for a in abs_data:
        c.execute("INSERT INTO absences (eleve_id,classe_id,date_abs,duree_h,justifiee) VALUES (?,?,?,?,?)", a)

    # ── EVENEMENTS ────────────────────────────────────────────────────────────
    evts = [
        ('Début Séquence 1','','2025-01-06',None,'sequence','all'),
        ('Fête du Collège La Pensée','Grande fête annuelle','2025-01-20','2025-01-20','fete','all'),
        ('Réunion Parents (FR)','Réunion trimestrielle','2025-02-02',None,'reunion','fr'),
        ('Parents Meeting (EN)','Termly meeting','2025-02-08',None,'reunion','en'),
        ('Fin Séquence 1','','2025-02-14',None,'sequence','all'),
        ('Fête Nationale (11 Fév.)','','2025-02-11',None,'conge','all'),
        ('Début Séquence 2','','2025-02-17',None,'sequence','all'),
        ('Fête Nationale (20 Mai)','','2025-05-20',None,'conge','all'),
        ('Fin Année Scolaire 2024-2025','','2025-07-31',None,'sequence','all'),
    ]
    for ev in evts:
        c.execute("INSERT INTO evenements (titre,description,date_debut,date_fin,type,section) VALUES (?,?,?,?,?,?)", ev)

    # ── PUBLICATIONS ──────────────────────────────────────────────────────────
    pubs = [
        ('Résultats Séquence 1 — 2024/2025','Les résultats sont disponibles.','annonce',None,'all'),
        ('Programme Fête du Collège 2025','La fête aura lieu le 20 Janvier 2025.','image',None,'all'),
        ('Chronogramme Séquence 2','Planning de la deuxième séquence.','pdf',None,'all'),
    ]
    for p in pubs:
        c.execute("INSERT INTO publications (titre,description,type,fichier,section) VALUES (?,?,?,?,?)", p)

    conn.commit()
    print("[CBLP] Données de démonstration chargées.")


if __name__ == '__main__':
    init_db()
