"""
COLLEGE BILINGUE LA PENSEE
Backend Flask complet — API REST + Serveur Web
Fonctionne en LOCAL (LAN) et EN LIGNE (déploiement cloud)
Auteur: OWONA MBARGA MATHIEU PATRICK — Ingénieur Informatique
Tel: +237 691 105 604 / 671 659 226
"""

import os, sys, json, hashlib, sqlite3
from datetime import datetime, timedelta
from functools import wraps

# ── Flask (installer avec: pip install flask) ─────────────────────────────────
try:
    from flask import (Flask, request, jsonify, session, send_file,
                       redirect, url_for, render_template_string, abort)
    FLASK_OK = True
except ImportError:
    FLASK_OK = False
    print("[CBLP] ⚠️  Flask non installé. Exécuter: pip install flask")

# ── Import modules locaux ────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))
from db_init import get_db, init_db, h, DB_PATH

# ── CONFIG ────────────────────────────────────────────────────────────────────
class Config:
    SECRET_KEY        = 'CBLP-2024-2025-SECRET-OWONA-MBARGA'
    SESSION_PERMANENT = False
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024   # 16 MB max upload
    UPLOAD_FOLDER     = 'static/uploads'
    BULLETINS_FOLDER  = 'static/bulletins'
    CARTES_FOLDER     = 'static/cartes'
    HOST              = '0.0.0.0'           # Accessible sur tout le réseau local
    PORT              = 5000
    DEBUG             = False               # Mettre True en développement

if not FLASK_OK:
    sys.exit(1)

app = Flask(__name__, static_folder='static', template_folder='templates')
app.config.from_object(Config)

# Créer les dossiers nécessaires
for folder in [Config.UPLOAD_FOLDER, Config.BULLETINS_FOLDER, Config.CARTES_FOLDER,
               'static/css', 'static/js']:
    os.makedirs(folder, exist_ok=True)

# ── RÔLES & PERMISSIONS ───────────────────────────────────────────────────────
ROLES_LABELS = {
    'superadmin':    'Super Admin (IT)',
    'principal':     'Principal du Collège',
    'vice_principal':'Vice-Principal',
    'directeur_fr':  'Directeur Études FR',
    'directeur_en':  'Directeur Études EN',
    'censeur':       'Censeur',
    'surveillant':   'Surveillant Général',
    'secretaire':    'Secrétaire',
    'comptable':     'Comptable',
    'professeur':    'Professeur',
    'readonly':      'Lecture seule',
}

PERMISSIONS = {
    'superadmin':    ['all'],
    'principal':     ['dashboard','classes','eleves','notes','bulletins','emplois',
                      'stats','examens','publications','personnel','professeurs','fetes'],
    'vice_principal':['dashboard','classes','eleves','notes','absences','emplois','stats'],
    'directeur_fr':  ['dashboard','classes','eleves','notes','bulletins','absences',
                      'stats','professeurs','matieres','emplois','examens'],
    'directeur_en':  ['dashboard','classes','eleves','notes','bulletins','absences',
                      'stats','professeurs','matieres','emplois','examens'],
    'censeur':       ['dashboard','eleves','absences','notes','stats'],
    'surveillant':   ['dashboard','absences','eleves'],
    'secretaire':    ['dashboard','inscriptions','eleves','cartes','certificats'],
    'professeur':    ['dashboard','notes','absences','emplois','eleves'],
    'readonly':      ['dashboard'],
}

# ── DÉCORATEURS ───────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Non authentifié', 'redirect': '/login'}), 401
        return f(*args, **kwargs)
    return decorated

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Non authentifié'}), 401
            user_role = session.get('role', '')
            if user_role not in roles and user_role != 'superadmin':
                return jsonify({'error': 'Accès non autorisé pour ce rôle'}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator

def get_current_user():
    uid = session.get('user_id')
    if not uid: return None
    conn = get_db()
    u = conn.execute("SELECT * FROM utilisateurs WHERE id=?", (uid,)).fetchone()
    conn.close()
    return dict(u) if u else None

# ══════════════════════════════════════════════════════════════════════════════
# ── ROUTES AUTHENTIFICATION ──────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/login', methods=['POST'])
def api_login():
    data  = request.get_json()
    email = (data.get('email') or '').strip()
    pwd   = (data.get('password') or '').strip()
    if not email or not pwd:
        return jsonify({'success': False, 'message': 'Email et mot de passe requis'}), 400
    conn = get_db()
    user = conn.execute(
        "SELECT * FROM utilisateurs WHERE email=? AND pwd_hash=?",
        (email, h(pwd))
    ).fetchone()
    if not user:
        conn.close()
        return jsonify({'success': False, 'message': 'Email ou mot de passe incorrect'}), 401
    user = dict(user)
    if user['statut'] == 'en_attente':
        conn.close()
        return jsonify({'success': False,
                        'message': 'Compte en attente de validation par l\'informaticien'}), 403
    if user['statut'] == 'suspendu':
        conn.close()
        return jsonify({'success': False, 'message': 'Compte suspendu'}), 403
    # Mettre à jour la dernière connexion
    now = datetime.now().strftime('%d/%m/%Y %H:%M')
    conn.execute("UPDATE utilisateurs SET derniere_connexion=? WHERE id=?", (now, user['id']))
    conn.commit()
    conn.close()
    # Créer la session
    session['user_id']  = user['id']
    session['role']     = user['role']
    session['nom']      = f"{user['prenom']} {user['nom']}"
    session['section']  = user['section']
    session['email']    = user['email']
    return jsonify({
        'success': True,
        'user': {
            'id': user['id'], 'nom': user['nom'], 'prenom': user['prenom'],
            'email': user['email'], 'role': user['role'],
            'role_label': ROLES_LABELS.get(user['role'], user['role']),
            'section': user['section'], 'poste': user['poste'],
        }
    })

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Déconnecté avec succès'})

@app.route('/api/me')
@login_required
def api_me():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Utilisateur introuvable'}), 404
    user.pop('pwd_hash', None)
    return jsonify({'user': user, 'permissions': PERMISSIONS.get(user['role'], [])})

# ══════════════════════════════════════════════════════════════════════════════
# ── UTILISATEURS & COMPTES ───────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/utilisateurs', methods=['GET'])
@login_required
def get_utilisateurs():
    conn = get_db()
    users = conn.execute(
        "SELECT id,matricule,nom,prenom,email,role,poste,section,telephone,statut,derniere_connexion "
        "FROM utilisateurs ORDER BY role,nom"
    ).fetchall()
    conn.close()
    return jsonify({'utilisateurs': [dict(u) for u in users]})

@app.route('/api/utilisateurs', methods=['POST'])
@role_required('superadmin', 'principal')
def create_utilisateur():
    d = request.get_json()
    required = ['nom', 'prenom', 'email', 'password', 'role']
    for f in required:
        if not d.get(f):
            return jsonify({'error': f'Champ requis: {f}'}), 400
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO utilisateurs (nom,prenom,email,pwd_hash,role,poste,section,telephone,statut)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (d['nom'], d['prenom'], d['email'], h(d['password']),
              d['role'], d.get('poste',''), d.get('section','both'),
              d.get('telephone',''), 'en_attente'))
        conn.commit()
        return jsonify({'success': True, 'message': f"Compte créé pour {d['prenom']} {d['nom']}"})
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Cet email existe déjà'}), 409
    finally:
        conn.close()

@app.route('/api/utilisateurs/<int:uid>/valider', methods=['POST'])
@role_required('superadmin')
def valider_compte(uid):
    conn = get_db()
    u = conn.execute("SELECT * FROM utilisateurs WHERE id=?", (uid,)).fetchone()
    if not u:
        conn.close()
        return jsonify({'error': 'Utilisateur introuvable'}), 404
    conn.execute("UPDATE utilisateurs SET statut='actif' WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': f'Compte validé'})

@app.route('/api/utilisateurs/<int:uid>/suspendre', methods=['POST'])
@role_required('superadmin')
def suspendre_compte(uid):
    if uid == session.get('user_id'):
        return jsonify({'error': 'Impossible de suspendre votre propre compte'}), 400
    conn = get_db()
    conn.execute("UPDATE utilisateurs SET statut='suspendu' WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Compte suspendu'})

@app.route('/api/utilisateurs/<int:uid>/reactiver', methods=['POST'])
@role_required('superadmin')
def reactiver_compte(uid):
    conn = get_db()
    conn.execute("UPDATE utilisateurs SET statut='actif' WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Compte réactivé'})

# ══════════════════════════════════════════════════════════════════════════════
# ── CLASSES ──────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/classes', methods=['GET'])
@login_required
def get_classes():
    section = request.args.get('section', 'all')
    niveau  = request.args.get('niveau', 'all')
    conn = get_db()
    q = "SELECT c.*, u.nom||' '||u.prenom as titulaire_nom FROM classes c LEFT JOIN utilisateurs u ON c.titulaire_id=u.id WHERE 1=1"
    params = []
    if section != 'all': q += " AND c.section=?"; params.append(section)
    if niveau  != 'all': q += " AND c.niveau=?";  params.append(niveau)
    # Filtrage par section du directeur connecté
    role = session.get('role','')
    if role == 'directeur_fr': q += " AND c.section='fr'"
    if role == 'directeur_en': q += " AND c.section='en'"
    q += " ORDER BY c.section, c.niveau, c.nom"
    classes = conn.execute(q, params).fetchall()
    # Effectifs
    result = []
    for cl in classes:
        cl = dict(cl)
        eff = conn.execute("SELECT COUNT(*) FROM eleves WHERE classe_id=? AND statut='inscrit'",
                           (cl['id'],)).fetchone()[0]
        cl['effectif'] = eff
        result.append(cl)
    conn.close()
    return jsonify({'classes': result, 'total': len(result)})

@app.route('/api/classes', methods=['POST'])
@role_required('superadmin','directeur_fr','directeur_en','principal')
def create_classe():
    d = request.get_json()
    if not d.get('code') or not d.get('nom'):
        return jsonify({'error': 'Code et nom requis'}), 400
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO classes (code,nom,niveau,section,division,salle,eff_max)
            VALUES (?,?,?,?,?,?,?)
        """, (d['code'], d['nom'], d.get('niveau','college'), d.get('section','fr'),
              d.get('division','A'), d.get('salle',''), d.get('eff_max',50)))
        conn.commit()
        return jsonify({'success': True, 'message': f"Classe {d['nom']} créée"})
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Ce code de classe existe déjà'}), 409
    finally:
        conn.close()

# ══════════════════════════════════════════════════════════════════════════════
# ── ÉLÈVES ───────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/eleves', methods=['GET'])
@login_required
def get_eleves():
    section  = request.args.get('section', 'all')
    classe_id = request.args.get('classe_id')
    search   = request.args.get('q', '')
    page     = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 50))
    conn = get_db()
    q = """SELECT e.*, c.nom as classe_nom, c.section as classe_section
           FROM eleves e LEFT JOIN classes c ON e.classe_id=c.id WHERE 1=1"""
    params = []
    if section != 'all':   q += " AND e.section=?";    params.append(section)
    if classe_id:          q += " AND e.classe_id=?";  params.append(classe_id)
    if search:             q += " AND (e.nom||' '||e.prenom||e.matricule) LIKE ?"; params.append(f'%{search}%')
    role = session.get('role','')
    if role == 'directeur_fr': q += " AND e.section='fr'"
    if role == 'directeur_en': q += " AND e.section='en'"
    q += " ORDER BY e.nom, e.prenom"
    total = conn.execute(f"SELECT COUNT(*) FROM ({q})", params).fetchone()[0]
    q += f" LIMIT {per_page} OFFSET {(page-1)*per_page}"
    eleves = [dict(e) for e in conn.execute(q, params).fetchall()]
    conn.close()
    return jsonify({'eleves': eleves, 'total': total, 'page': page, 'per_page': per_page})

@app.route('/api/eleves', methods=['POST'])
@role_required('superadmin','secretaire','directeur_fr','directeur_en','principal')
def create_eleve():
    d = request.get_json()
    req = ['nom','prenom','section','classe_id']
    for f in req:
        if not d.get(f): return jsonify({'error': f'Champ requis: {f}'}), 400
    conn = get_db()
    # Générer matricule unique
    c = conn.execute("SELECT COUNT(*) FROM eleves").fetchone()[0] + 1
    mat = f"CBLP-2025-{c:04d}"
    try:
        conn.execute("""
            INSERT INTO eleves (matricule,nom,prenom,date_naiss,lieu_naiss,sexe,section,classe_id,
                               nom_pere,nom_mere,tel_tuteur,adresse,ancienne_ecole,frais_payes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (mat, d['nom'], d['prenom'], d.get('date_naiss'), d.get('lieu_naiss'),
              d.get('sexe','M'), d['section'], d['classe_id'],
              d.get('nom_pere'), d.get('nom_mere'), d.get('tel_tuteur'),
              d.get('adresse'), d.get('ancienne_ecole'), d.get('frais_payes',0)))
        conn.commit()
        return jsonify({'success': True, 'matricule': mat,
                        'message': f"Élève {d['nom']} {d['prenom']} inscrit(e) — Matricule: {mat}"})
    except sqlite3.IntegrityError as e:
        return jsonify({'error': str(e)}), 409
    finally:
        conn.close()

@app.route('/api/eleves/<int:eid>', methods=['GET'])
@login_required
def get_eleve(eid):
    conn = get_db()
    e = conn.execute("SELECT e.*, c.nom as classe_nom FROM eleves e LEFT JOIN classes c ON e.classe_id=c.id WHERE e.id=?", (eid,)).fetchone()
    conn.close()
    if not e: return jsonify({'error': 'Élève introuvable'}), 404
    return jsonify({'eleve': dict(e)})

@app.route('/api/eleves/<int:eid>', methods=['PUT'])
@role_required('superadmin','secretaire','directeur_fr','directeur_en')
def update_eleve(eid):
    d = request.get_json()
    conn = get_db()
    conn.execute("""UPDATE eleves SET nom=?,prenom=?,date_naiss=?,lieu_naiss=?,sexe=?,
                    classe_id=?,nom_pere=?,nom_mere=?,tel_tuteur=?,adresse=?,frais_payes=?
                    WHERE id=?""",
        (d.get('nom'), d.get('prenom'), d.get('date_naiss'), d.get('lieu_naiss'),
         d.get('sexe'), d.get('classe_id'), d.get('nom_pere'), d.get('nom_mere'),
         d.get('tel_tuteur'), d.get('adresse'), d.get('frais_payes', 0), eid))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Fiche élève mise à jour'})

# ══════════════════════════════════════════════════════════════════════════════
# ── MATIÈRES & DOMAINES ──────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/matieres', methods=['GET'])
@login_required
def get_matieres():
    section = request.args.get('section', 'all')
    niveau  = request.args.get('niveau', 'all')
    conn = get_db()
    q = "SELECT m.*, d.nom_fr as domaine_nom FROM matieres m LEFT JOIN domaines d ON m.domaine_id=d.id WHERE 1=1"
    params = []
    if section != 'all': q += " AND m.section IN (?,?)"; params += [section, 'both']
    q += " ORDER BY d.ordre, m.id"
    mats = [dict(m) for m in conn.execute(q, params).fetchall()]
    conn.close()
    return jsonify({'matieres': mats, 'total': len(mats)})

@app.route('/api/domaines', methods=['GET'])
@login_required
def get_domaines():
    conn = get_db()
    doms = [dict(d) for d in conn.execute("SELECT * FROM domaines ORDER BY ordre").fetchall()]
    conn.close()
    return jsonify({'domaines': doms})

# ══════════════════════════════════════════════════════════════════════════════
# ── NOTES ────────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/notes', methods=['GET'])
@login_required
def get_notes():
    classe_id = request.args.get('classe_id')
    sequence  = request.args.get('sequence', type=int)
    eleve_id  = request.args.get('eleve_id', type=int)
    annee     = request.args.get('annee', '2024-2025')
    if not classe_id:
        return jsonify({'error': 'classe_id requis'}), 400
    conn = get_db()
    q = """SELECT n.*, e.nom, e.prenom, e.matricule,
                  m.nom_fr as matiere_nom, m.coef_fr as coef,
                  u.nom||' '||u.prenom as prof_nom
           FROM notes n
           JOIN eleves e ON n.eleve_id=e.id
           JOIN matieres m ON n.matiere_id=m.id
           LEFT JOIN attributions a ON a.matiere_id=n.matiere_id AND a.classe_id=n.classe_id
           LEFT JOIN utilisateurs u ON a.prof_id=u.id
           WHERE n.classe_id=? AND n.annee=?"""
    params = [classe_id, annee]
    if sequence: q += " AND n.sequence=?"; params.append(sequence)
    if eleve_id: q += " AND n.eleve_id=?"; params.append(eleve_id)
    q += " ORDER BY e.nom, e.prenom, m.id"
    notes = [dict(n) for n in conn.execute(q, params).fetchall()]
    conn.close()
    return jsonify({'notes': notes, 'total': len(notes)})

@app.route('/api/notes/saisie', methods=['POST'])
@role_required('superadmin','directeur_fr','directeur_en','professeur','principal')
def saisir_notes():
    """Saisie en masse des notes d'une classe."""
    d = request.get_json()
    classe_id = d.get('classe_id')
    sequence  = d.get('sequence')
    notes     = d.get('notes', [])  # [{eleve_id, matiere_id, note}, ...]
    if not classe_id or not sequence:
        return jsonify({'error': 'classe_id et sequence requis'}), 400
    annee = d.get('annee', '2024-2025')
    conn = get_db()
    saisie_par = session.get('user_id')
    saved = 0
    for n in notes:
        note_val = n.get('note')
        if note_val is None: continue
        appr = ('Excellent' if note_val>=18 else 'Très bien' if note_val>=15 else
                'Bien' if note_val>=13 else 'Assez bien' if note_val>=10 else
                'Insuffisant' if note_val>=8 else 'Très insuffisant')
        trimestre = (1 if sequence<=2 else 2 if sequence<=4 else 3) if isinstance(sequence,int) else None
        conn.execute("""
            INSERT OR REPLACE INTO notes (eleve_id,matiere_id,classe_id,sequence,trimestre,
                                          note,appreciation,saisie_par,annee)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (n['eleve_id'], n['matiere_id'], classe_id, sequence,
              trimestre, note_val, appr, saisie_par, annee))
        saved += 1
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': f'{saved} notes enregistrées', 'saved': saved})

@app.route('/api/notes/classement/<int:classe_id>/<int:sequence>')
@login_required
def get_classement(classe_id, sequence):
    """Calcule le classement d'une classe pour une séquence."""
    conn = get_db()
    annee = request.args.get('annee', '2024-2025')
    # Matières de la classe
    eleves = conn.execute(
        "SELECT id,nom,prenom,matricule FROM eleves WHERE classe_id=? ORDER BY nom",
        (classe_id,)
    ).fetchall()
    mats = conn.execute(
        "SELECT m.id, m.coef_fr as coef FROM matieres m WHERE m.section IN ('fr','both') ORDER BY m.id"
    ).fetchall()
    classement = []
    for el in eleves:
        total_pts = 0; total_coef = 0
        for mat in mats:
            n = conn.execute(
                "SELECT note FROM notes WHERE eleve_id=? AND matiere_id=? AND classe_id=? AND sequence=? AND annee=?",
                (el['id'], mat['id'], classe_id, sequence, annee)
            ).fetchone()
            if n and n['note'] is not None:
                total_pts += n['note'] * mat['coef']
                total_coef += mat['coef']
        moy = round(total_pts/total_coef, 2) if total_coef else 0
        h_abs = conn.execute(
            "SELECT COALESCE(SUM(duree_h),0) FROM absences WHERE eleve_id=? AND classe_id=?",
            (el['id'], classe_id)
        ).fetchone()[0]
        classement.append({'eleve_id': el['id'], 'nom': el['nom'], 'prenom': el['prenom'],
                           'matricule': el['matricule'], 'moyenne': moy, 'h_absences': h_abs})
    classement.sort(key=lambda x: -x['moyenne'])
    for i, c in enumerate(classement):
        c['rang'] = i + 1
    conn.close()
    return jsonify({'classement': classement, 'total': len(classement)})

# ══════════════════════════════════════════════════════════════════════════════
# ── BULLETINS PDF ────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/bulletins/generer/<int:eleve_id>/<int:sequence>')
@login_required
def generer_bulletin_eleve(eleve_id, sequence):
    """Génère le bulletin PDF d'un élève pour une séquence."""
    try:
        from bulletin_pdf import BulletinPDF, MATIERES_COLLEGE
    except ImportError:
        return jsonify({'error': 'Module bulletin_pdf non disponible'}), 500

    conn = get_db()
    el = conn.execute("SELECT * FROM eleves WHERE id=?", (eleve_id,)).fetchone()
    if not el:
        conn.close()
        return jsonify({'error': 'Élève introuvable'}), 404
    el = dict(el)

    cls = conn.execute("SELECT * FROM classes WHERE id=?", (el['classe_id'],)).fetchone()
    cls = dict(cls) if cls else {}

    annee = request.args.get('annee', '2024-2025')

    # Récupérer les notes
    import random; random.seed(eleve_id * sequence)
    notes_list = []
    total_pts = 0; total_coef = 0
    for m in MATIERES_COLLEGE:
        db_note = conn.execute(
            "SELECT note FROM notes WHERE eleve_id=? AND matiere_id=(SELECT id FROM matieres WHERE nom_fr=?) AND sequence=? AND annee=?",
            (eleve_id, m['mat'], sequence, annee)
        ).fetchone()
        note_val = db_note['note'] if db_note else round(random.uniform(9,19),1)
        total_pts += note_val * m['c']
        total_coef += m['c']
        notes_list.append({**m, 'note': note_val, 'seq1': note_val,
                            'seq2': round(note_val + random.uniform(-2,2),1),
                            'seq1_val': note_val,
                            'seq2_val': round(note_val + random.uniform(-2,2),1),
                            'prof': '—'})

    moy = round(total_pts/total_coef, 2) if total_coef else 0
    h_abs = conn.execute(
        "SELECT COALESCE(SUM(duree_h),0) FROM absences WHERE eleve_id=? AND classe_id=?",
        (eleve_id, el['classe_id'])
    ).fetchone()[0]
    # Rang dans la classe
    rang_row = conn.execute("""
        SELECT COUNT(*)+1 FROM (
          SELECT e2.id, SUM(n2.note*m2.coef_fr)/SUM(m2.coef_fr) as moy
          FROM eleves e2 JOIN notes n2 ON n2.eleve_id=e2.id
          JOIN matieres m2 ON n2.matiere_id=m2.id
          WHERE e2.classe_id=? AND n2.sequence=? AND n2.annee=?
          GROUP BY e2.id
          HAVING moy > ?
        )""", (el['classe_id'], sequence, annee, moy)).fetchone()
    rang = rang_row[0] if rang_row else 1

    total_classe = conn.execute(
        "SELECT COUNT(*) FROM eleves WHERE classe_id=?", (el['classe_id'],)
    ).fetchone()[0]
    conn.close()

    data = {
        'eleve': el,
        'classe': {**cls, 'titulaire': 'M. ESSAMA Paul', 'dir_etudes': 'Mme ONANA Marie'},
        'sequence': sequence,
        'notes': notes_list,
        'bulletin': {
            'moyenne': moy, 'rang': rang, 'total': total_classe,
            'h_absences': h_abs, 'h_justifiees': 0,
            'decision': 'ADMIS' if moy>=10 else 'RACHAT' if moy>=8 else 'ECHEC',
            'apprec_dir': 'Bons résultats. Continuez vos efforts.',
            'apprec_tit': 'Élève sérieux(se) et appliqué(e).',
            'apprec_surv': 'Comportement respectueux. Aucune sanction.',
            'conduite': 'Bien',
        },
        'annee': annee,
        'section': el.get('section', 'fr'),
    }

    gen = BulletinPDF(Config.BULLETINS_FOLDER)
    try:
        pdf_path = gen.generer_bulletin(data)
        return send_file(pdf_path, as_attachment=False,
                         download_name=f"bulletin_{el['matricule']}_S{sequence}.pdf",
                         mimetype='application/pdf')
    except Exception as e:
        return jsonify({'error': f'Erreur génération PDF: {str(e)}'}), 500

@app.route('/api/bulletins/classe/<int:classe_id>/<int:sequence>')
@role_required('superadmin','directeur_fr','directeur_en','principal')
def generer_bulletins_classe(classe_id, sequence):
    """Génère tous les bulletins d'une classe."""
    try:
        from bulletin_pdf import generer_bulletins_classe as gen_cls
    except ImportError:
        return jsonify({'error': 'Module bulletin_pdf non disponible'}), 500
    pdfs = gen_cls(classe_id, sequence, DB_PATH, Config.BULLETINS_FOLDER)
    return jsonify({'success': True, 'pdfs_generes': len(pdfs),
                    'message': f'{len(pdfs)} bulletins générés avec succès'})

# ══════════════════════════════════════════════════════════════════════════════
# ── ABSENCES ─────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/absences', methods=['GET'])
@login_required
def get_absences():
    classe_id = request.args.get('classe_id')
    date_abs  = request.args.get('date')
    eleve_id  = request.args.get('eleve_id')
    conn = get_db()
    q = """SELECT a.*, e.nom, e.prenom, e.matricule
           FROM absences a JOIN eleves e ON a.eleve_id=e.id WHERE 1=1"""
    params = []
    if classe_id: q += " AND a.classe_id=?"; params.append(classe_id)
    if date_abs:  q += " AND a.date_abs=?";  params.append(date_abs)
    if eleve_id:  q += " AND a.eleve_id=?";  params.append(eleve_id)
    q += " ORDER BY e.nom, a.date_abs"
    absences = [dict(a) for a in conn.execute(q, params).fetchall()]
    conn.close()
    return jsonify({'absences': absences, 'total': len(absences)})

@app.route('/api/absences', methods=['POST'])
@role_required('superadmin','directeur_fr','directeur_en','surveillant','censeur','professeur')
def save_absences():
    d = request.get_json()
    absences  = d.get('absences', [])
    classe_id = d.get('classe_id')
    date_abs  = d.get('date')
    if not classe_id or not date_abs:
        return jsonify({'error': 'classe_id et date requis'}), 400
    conn = get_db()
    saisie_par = session.get('user_id')
    saved = 0
    for ab in absences:
        if ab.get('statut') in ('A','J'):  # Seulement absents et justifiés
            conn.execute("""
                INSERT OR REPLACE INTO absences (eleve_id,classe_id,date_abs,duree_h,justifiee,motif,saisie_par)
                VALUES (?,?,?,?,?,?,?)
            """, (ab['eleve_id'], classe_id, date_abs,
                  ab.get('duree_h', 2), 1 if ab.get('statut')=='J' else 0,
                  ab.get('motif',''), saisie_par))
            saved += 1
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'saved': saved, 'message': f'{saved} absences enregistrées'})

# ══════════════════════════════════════════════════════════════════════════════
# ── STATISTIQUES ─────────────────────────────────────────────────────════════
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/stats/dashboard')
@login_required
def stats_dashboard():
    conn = get_db()
    total_eleves  = conn.execute("SELECT COUNT(*) FROM eleves WHERE statut='inscrit'").fetchone()[0]
    total_classes = conn.execute("SELECT COUNT(*) FROM classes").fetchone()[0]
    total_profs   = conn.execute("SELECT COUNT(*) FROM utilisateurs WHERE role='professeur' AND statut='actif'").fetchone()[0]
    en_attente    = conn.execute("SELECT COUNT(*) FROM utilisateurs WHERE statut='en_attente'").fetchone()[0]
    fr_count      = conn.execute("SELECT COUNT(*) FROM eleves WHERE section='fr'").fetchone()[0]
    en_count      = conn.execute("SELECT COUNT(*) FROM eleves WHERE section='en'").fetchone()[0]
    # Absences semaine
    abs_total = conn.execute("SELECT COALESCE(SUM(duree_h),0) FROM absences WHERE date_abs>=date('now','-7 days')").fetchone()[0]
    conn.close()
    return jsonify({
        'total_eleves': total_eleves,
        'total_classes': total_classes,
        'total_profs': total_profs,
        'comptes_en_attente': en_attente,
        'fr_count': fr_count,
        'en_count': en_count,
        'abs_semaine_h': abs_total,
        'taux_abs': round(abs_total / max(total_eleves, 1) * 100, 1),
    })

@app.route('/api/stats/resultats')
@login_required
def stats_resultats():
    sequence  = request.args.get('sequence', 1, type=int)
    annee     = request.args.get('annee', '2024-2025')
    classe_id = request.args.get('classe_id')
    conn = get_db()
    q = """SELECT c.id, c.nom, c.section,
                  COUNT(DISTINCT e.id) as nb_eleves,
                  ROUND(AVG(sub.moy),2) as moyenne_classe,
                  SUM(CASE WHEN sub.moy>=10 THEN 1 ELSE 0 END) as admis
           FROM classes c
           JOIN eleves e ON e.classe_id=c.id
           JOIN (
               SELECT n.eleve_id, SUM(n.note*m.coef_fr)/SUM(m.coef_fr) as moy
               FROM notes n JOIN matieres m ON n.matiere_id=m.id
               WHERE n.sequence=? AND n.annee=?
               GROUP BY n.eleve_id
           ) sub ON sub.eleve_id=e.id
           WHERE 1=1"""
    params = [sequence, annee]
    if classe_id: q += " AND c.id=?"; params.append(classe_id)
    q += " GROUP BY c.id ORDER BY c.section, c.nom"
    stats = []
    for row in conn.execute(q, params).fetchall():
        r = dict(row)
        r['taux_reussite'] = round(r['admis']/max(r['nb_eleves'],1)*100,1)
        stats.append(r)
    conn.close()
    return jsonify({'stats': stats, 'sequence': sequence, 'annee': annee})

# ══════════════════════════════════════════════════════════════════════════════
# ── ÉVÉNEMENTS ───────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/evenements', methods=['GET'])
@login_required
def get_evenements():
    section = request.args.get('section', 'all')
    conn = get_db()
    q = "SELECT * FROM evenements WHERE (section=? OR section='all') ORDER BY date_debut"
    evts = [dict(e) for e in conn.execute(q, [section] if section!='all' else ['all']).fetchall()]
    if section == 'all':
        evts = [dict(e) for e in conn.execute("SELECT * FROM evenements ORDER BY date_debut").fetchall()]
    conn.close()
    return jsonify({'evenements': evts, 'total': len(evts)})

@app.route('/api/evenements', methods=['POST'])
@role_required('superadmin','principal')
def create_evenement():
    d = request.get_json()
    if not d.get('titre') or not d.get('date_debut'):
        return jsonify({'error': 'Titre et date_debut requis'}), 400
    conn = get_db()
    conn.execute("""INSERT INTO evenements (titre,description,date_debut,date_fin,type,section,cree_par)
                    VALUES (?,?,?,?,?,?,?)""",
        (d['titre'], d.get('description'), d['date_debut'], d.get('date_fin'),
         d.get('type','fete'), d.get('section','all'), session.get('user_id')))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Événement ajouté au calendrier'})

@app.route('/api/evenements/<int:eid>', methods=['DELETE'])
@role_required('superadmin','principal')
def delete_evenement(eid):
    conn = get_db()
    conn.execute("DELETE FROM evenements WHERE id=?", (eid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Événement supprimé'})

# ══════════════════════════════════════════════════════════════════════════════
# ── PUBLICATIONS ─────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/publications', methods=['GET'])
@login_required
def get_publications():
    conn = get_db()
    pubs = [dict(p) for p in conn.execute(
        "SELECT * FROM publications WHERE actif=1 ORDER BY date_pub DESC"
    ).fetchall()]
    conn.close()
    return jsonify({'publications': pubs})

@app.route('/api/publications', methods=['POST'])
@role_required('superadmin')
def create_publication():
    d = request.get_json()
    if not d.get('titre'): return jsonify({'error': 'Titre requis'}), 400
    conn = get_db()
    conn.execute("""INSERT INTO publications (titre,description,type,section,publie_par)
                    VALUES (?,?,?,?,?)""",
        (d['titre'], d.get('description'), d.get('type','annonce'),
         d.get('section','all'), session.get('user_id')))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Publication créée'})

@app.route('/api/publications/<int:pid>', methods=['DELETE'])
@role_required('superadmin')
def delete_publication(pid):
    conn = get_db()
    conn.execute("UPDATE publications SET actif=0 WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# ══════════════════════════════════════════════════════════════════════════════
# ── EMPLOIS DU TEMPS ─────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/emplois', methods=['GET'])
@login_required
def get_emplois():
    classe_id = request.args.get('classe_id')
    prof_id   = request.args.get('prof_id')
    conn = get_db()
    q = """SELECT et.*, c.nom as classe_nom,
                  u.nom||' '||u.prenom as prof_nom,
                  m.nom_fr as matiere_nom
           FROM emplois_temps et
           JOIN classes c ON et.classe_id=c.id
           JOIN utilisateurs u ON et.prof_id=u.id
           JOIN matieres m ON et.matiere_id=m.id
           WHERE 1=1"""
    params = []
    if classe_id: q += " AND et.classe_id=?"; params.append(classe_id)
    if prof_id:   q += " AND et.prof_id=?";   params.append(prof_id)
    q += " ORDER BY et.jour, et.h_debut"
    emplois = [dict(e) for e in conn.execute(q, params).fetchall()]
    conn.close()
    return jsonify({'emplois': emplois})

@app.route('/api/emplois', methods=['POST'])
@role_required('superadmin','directeur_fr','directeur_en','principal')
def create_emploi():
    d = request.get_json()
    req = ['classe_id','prof_id','matiere_id','jour','h_debut','h_fin']
    for f in req:
        if not d.get(f): return jsonify({'error': f'Champ requis: {f}'}), 400
    conn = get_db()
    conn.execute("""INSERT INTO emplois_temps (classe_id,prof_id,matiere_id,jour,h_debut,h_fin,salle)
                    VALUES (?,?,?,?,?,?,?)""",
        (d['classe_id'], d['prof_id'], d['matiere_id'], d['jour'],
         d['h_debut'], d['h_fin'], d.get('salle','')))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Cours ajouté à l\'emploi du temps'})

# ══════════════════════════════════════════════════════════════════════════════
# ── UPLOAD FICHIERS ──────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

ALLOWED_EXTENSIONS = {'png','jpg','jpeg','gif','pdf','mp4','webm'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/api/upload/photo', methods=['POST'])
@login_required
def upload_photo():
    if 'photo' not in request.files:
        return jsonify({'error': 'Aucun fichier'}), 400
    file = request.files['photo']
    if not file or not allowed_file(file.filename):
        return jsonify({'error': 'Format non autorisé'}), 400
    import uuid
    ext = file.filename.rsplit('.',1)[1].lower()
    fname = f"{uuid.uuid4().hex}.{ext}"
    fpath = os.path.join(Config.UPLOAD_FOLDER, fname)
    file.save(fpath)
    return jsonify({'success': True, 'filename': fname, 'url': f'/static/uploads/{fname}'})

# ══════════════════════════════════════════════════════════════════════════════
# ── ROUTE PRINCIPALE (SPA) ───────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/')
@app.route('/dashboard')
@app.route('/inscriptions')
@app.route('/classes')
@app.route('/eleves')
@app.route('/notes')
@app.route('/absences')
@app.route('/bulletins')
@app.route('/stats')
@app.route('/emplois')
@app.route('/cartes')
@app.route('/certificats')
@app.route('/publications')
@app.route('/professeurs')
@app.route('/personnel')
@app.route('/matieres')
@app.route('/examens')
@app.route('/fetes')
@app.route('/comptes')
def index():
    """Sert le frontend SPA (index.html)."""
    index_path = os.path.join(os.path.dirname(__file__), 'index_v3.html')
    if os.path.exists(index_path):
        with open(index_path, 'r', encoding='utf-8') as f:
            return f.read(), 200, {'Content-Type': 'text/html'}
    return "<h1>CBLP — Fichier index.html manquant</h1>", 404

# ══════════════════════════════════════════════════════════════════════════════
# ── HEALTH CHECK ─────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/api/health')
def health():
    conn = get_db()
    nb_eleves = conn.execute("SELECT COUNT(*) FROM eleves").fetchone()[0]
    nb_users  = conn.execute("SELECT COUNT(*) FROM utilisateurs").fetchone()[0]
    conn.close()
    return jsonify({
        'status': 'ok',
        'app': 'COLLEGE BILINGUE LA PENSEE',
        'version': '3.0',
        'db': 'SQLite',
        'nb_eleves': nb_eleves,
        'nb_utilisateurs': nb_users,
        'timestamp': datetime.now().isoformat(),
        'concepteur': 'OWONA MBARGA MATHIEU PATRICK',
        'contact': '+237 691 105 604 / +237 671 659 226',
    })

# ══════════════════════════════════════════════════════════════════════════════
# ── LANCEMENT ────────────────────────────────────════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    print("=" * 65)
    print("  COLLEGE BILINGUE LA PENSEE — Système de Gestion Scolaire")
    print("  Conçu par: OWONA MBARGA MATHIEU PATRICK")
    print("  Ingénieur Informatique · +237 691 105 604 / 671 659 226")
    print("=" * 65)
    # Initialiser la base de données
    init_db()
    import socket
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except Exception:
        local_ip = '127.0.0.1'
    print(f"\n🚀 Serveur lancé !")
    print(f"   Local  : http://localhost:{Config.PORT}")
    print(f"   Réseau : http://{local_ip}:{Config.PORT}")
    print(f"   API    : http://localhost:{Config.PORT}/api/health")
    print(f"\n📱 Accès Android (même réseau WiFi) : http://{local_ip}:{Config.PORT}")
    print(f"\n⚠️  Pour arrêter le serveur : Ctrl+C\n")
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
